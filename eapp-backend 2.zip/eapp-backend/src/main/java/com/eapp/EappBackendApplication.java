package com.eapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EappBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EappBackendApplication.class, args);
	}

}
