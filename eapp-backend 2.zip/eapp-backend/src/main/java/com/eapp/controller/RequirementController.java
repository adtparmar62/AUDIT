
package com.eapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.dto.reponseDTO.BatchRequirementsDTO;
import com.eapp.dto.reponseDTO.DocumentRequestDTO;
import com.eapp.entity.UwRequirement;
import com.eapp.service.RequirementService;

@RestController
@RequestMapping("/api/uw/requirements")
//@CrossOrigin(origins = "*")
@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:3003" ,
		"http://internal-k8s-default-agenticu-dc7f68726f-1995427160.us-east-1.elb.amazonaws.com",
		"http://internal-k8s-default-agenticu-902b896a1f-1483840211.us-east-1.elb.amazonaws.com"
})
public class RequirementController {
	
	private static final Logger logger = LoggerFactory.getLogger(RequirementController.class);

    private final RequirementService requirementService;

    // Constructor injection (preferred)
    public RequirementController(RequirementService requirementService) {
        this.requirementService = requirementService;
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadDoc(@RequestBody DocumentRequestDTO dto) {
        logger.info("RequirementController.uploadDoc - Uploading document");
        try {
            if (dto == null || dto.getRequestPayload() == null) {
                return ResponseEntity.badRequest().body("Invalid Request: RequestPayload is missing.");
            }
            String result = requirementService.uploadRequirementDocument(dto.getRequestPayload());
            return ResponseEntity.ok(result);
        } catch (IllegalArgumentException iae) {
            return ResponseEntity.badRequest().body("Upload failed: " + iae.getMessage());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Upload failed: " + e.getMessage());
        }
    }

    @PostMapping("/save-batch")
    public ResponseEntity<String> saveBatch(@RequestBody BatchRequirementsDTO dto) {
        logger.info("RequirementController.saveBatch - Saving batch requirements for case: {}", dto.getTxnTypeId());
        try {
            requirementService.saveBatchRequirements(dto);
            return ResponseEntity.ok("Batch data saved successfully for Case: " + dto.getTxnTypeId());
        } catch (IllegalArgumentException iae) {
            return ResponseEntity.badRequest().body("Batch save failed: " + iae.getMessage());
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Batch save failed: " + e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<List<UwRequirement>> getAll() {
        List<UwRequirement> list = requirementService.getAll();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/{id}")
    public ResponseEntity<UwRequirement> getById(@PathVariable Long id) {
        try {
            UwRequirement entity = requirementService.getById(id);
            return ResponseEntity.ok(entity);
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/by-application")
    public ResponseEntity<List<UwRequirement>> getByApplication(
            @RequestParam("applicationNumber") String applicationNumber) {
        logger.info("RequirementController.getByApplication - Fetching requirements for application: {}", applicationNumber);
        List<UwRequirement> list = requirementService.getByApplicationNumber(applicationNumber);
        return ResponseEntity.ok(list);
    }
}
