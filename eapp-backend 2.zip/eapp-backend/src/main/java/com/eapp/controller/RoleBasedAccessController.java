package com.eapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.entity.Policy;
import com.eapp.entity.UwPolicy;
import com.eapp.service.RoleBasedAccessImpl;
import com.eapp.service.UwServiceImpl;

@RestController
@RequestMapping("/role")
public class RoleBasedAccessController {
	
	private static final Logger logger = LoggerFactory.getLogger(RoleBasedAccessController.class);
	
	@Autowired
	private RoleBasedAccessImpl role;
	
	@Autowired
	private UwServiceImpl uw;
	
	@GetMapping("/data-entry")
	public List<Policy> roleAccessDataEntry(@RequestParam String email){
		logger.info("RoleBasedAccessController.roleAccessDataEntry - Fetching data entry access for email: {}", email);
		return role.isAccessableApplication(email);
	}
	
	@GetMapping("/proofing")
	public List<Policy> roleAccessProofing(@RequestParam String email){
		logger.info("RoleBasedAccessController.roleAccessProofing - Fetching proofing access for email: {}", email);
		return role.isAccessableProofing(email);
	}
	
	@GetMapping("/underWriting")
	public List<UwPolicy> roleAccessUnderWriting(@RequestParam String email){
		logger.info("RoleBasedAccessController.roleAccessUnderWriting - Fetching underwriting access for email: {}", email);
		return uw.validUw(email);
	}
	

}
