package com.eapp.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.dto.SparkPolicyResult;
import com.eapp.dto.requestDTO.SparkTokenRequestDTO;
import com.eapp.service.spark.SparkService;
import com.eapp.service.spark.SparkTokenService;

@RestController
@RequestMapping("/api/autouw")
@CrossOrigin(origins = {
        "http://localhost:3000",
        "http://localhost:3003",
        "http://internal-k8s-default-agenticu-dc7f68726f-1995427160.us-east-1.elb.amazonaws.com",
        "http://internal-k8s-default-agenticu-902b896a1f-1483840211.us-east-1.elb.amazonaws.com"
})
public class SparkController {

    private static final Logger logger = LoggerFactory.getLogger(SparkController.class);

    private final SparkService sparkService;
    private final SparkTokenService sparkTokenService;

    public SparkController(SparkService sparkService, SparkTokenService sparkTokenService) {
        this.sparkService = sparkService;
        this.sparkTokenService = sparkTokenService;
    }

    @PostMapping("/spark-batch")
    public ResponseEntity<List<SparkPolicyResult>> triggerSparkBatch(
            @RequestBody(required = false) Map<String, String> body) {

        String policyId = (body != null) ? body.get("policyId") : null;

        if (policyId != null && !policyId.isBlank()) {
            // ── Single-policy path (triggered from the UI for a selected case) ──
            logger.info("SparkController.triggerSparkBatch - Triggering SPARK for single policyId={}",
                    policyId);
            return sparkService.triggerAutoUWForPolicy(policyId);
        }

        // ── Full-batch path (triggered by scheduler or manual batch action) ──
        logger.info("SparkController.triggerSparkBatch - Triggering SPARK batch for ALL policies");
        return sparkService.triggerAutoUWBatchAll();
    }

    @PostMapping("/spark-token-update")
    public ResponseEntity<String> updateSparkToken(@RequestBody SparkTokenRequestDTO sparkTokenRequestDTO) {
        logger.info("SparkController.updateSparkToken - Updating SPARK Token in DB");
        return sparkTokenService.updateSparkToken(sparkTokenRequestDTO);
    }
}