package com.eapp.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api/trigger")
@CrossOrigin(origins = {
        "http://localhost:3000",
        "http://localhost:3003"
})
public class TriggerController {

    private static final Logger logger = LoggerFactory.getLogger(TriggerController.class);

    @Value("${lambda.url.status3}")
    private String intakeUrl;

    @Value("${lambda.url.status6}")
    private String validationUrl;

    @Value("${lambda.url.status8}")
    private String recommendUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    @PostMapping("/intake")
    public ResponseEntity<?> triggerIntake(@RequestBody Map<String, String> body) {
        String quoteId = body.get("policyId"); // frontend sends policyId, we map it to quoteId
        logger.info("TriggerController.triggerIntake - Triggering Intake Agent for quoteId: {}", quoteId);
        try {
            // ✅ Lambda expects { "quoteId": "..." } in the request BODY
            Map<String, String> lambdaBody = Map.of("quoteId", quoteId);
            HttpEntity<Map<String, String>> request = buildRequest(lambdaBody);
            return restTemplate.postForEntity(intakeUrl, request, Object.class);
        } catch (Exception e) {
            logger.error("TriggerController.triggerIntake - Intake Agent failed: {}", e.getMessage());
            return ResponseEntity
                    .status(500)
                    .body(Map.of("error", "Intake Agent failed: " + e.getMessage()));
        }
    }

    @PostMapping("/validation")
    public ResponseEntity<?> triggerValidation(@RequestBody Map<String, String> body) {
        String quoteId = body.get("policyId"); // frontend sends policyId, we map it to quoteId
        logger.info("TriggerController.triggerValidation - Triggering Validation Agent for quoteId: {}", quoteId);
        try {
            // ✅ Lambda expects { "quoteId": "..." } in the request BODY
            Map<String, String> lambdaBody = Map.of("quoteId", quoteId);
            HttpEntity<Map<String, String>> request = buildRequest(lambdaBody);
            return restTemplate.postForEntity(validationUrl, request, Object.class);
        } catch (Exception e) {
            logger.error("TriggerController.triggerValidation - Validation Agent failed: {}", e.getMessage());
            return ResponseEntity
                    .status(500)
                    .body(Map.of("error", "Validation Agent failed: " + e.getMessage()));
        }
    }

    @PostMapping("/recommendation")
    public ResponseEntity<?> triggerRecommendation(@RequestBody Map<String, String> body) {
        String quoteId = body.get("policyId"); // frontend sends policyId, we map it to quoteId
        logger.info("TriggerController.triggerRecommendation - Triggering Recommendation Agent for quoteId: {}", quoteId);
        try {
            // ✅ Lambda expects { "quoteId": "..." } in the request BODY
            Map<String, String> lambdaBody = Map.of("quoteId", quoteId);
            HttpEntity<Map<String, String>> request = buildRequest(lambdaBody);
            return restTemplate.postForEntity(recommendUrl, request, Object.class);
        } catch (Exception e) {
            logger.error("TriggerController.triggerRecommendation - Recommendation Agent failed: {}", e.getMessage());
            return ResponseEntity
                    .status(500)
                    .body(Map.of("error", "Recommendation Agent failed: " + e.getMessage()));
        }
    }

    private HttpEntity<Map<String, String>> buildRequest(Map<String, String> body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return new HttpEntity<>(body, headers);
    }
}