package com.eapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.service.DropdownService;

@RestController
@RequestMapping("/eapp/dropdown")
//@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:3003" })
@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:3003" ,
		"http://internal-k8s-default-agenticu-dc7f68726f-1995427160.us-east-1.elb.amazonaws.com",
		"http://internal-k8s-default-agenticu-902b896a1f-1483840211.us-east-1.elb.amazonaws.com"
})
public class DropdownController {
	
	private static final Logger logger = LoggerFactory.getLogger(DropdownController.class);

	@Autowired
	private DropdownService dropdownService;

	@GetMapping("/getCoutries")
	public ResponseEntity<List<String>> findCountries() {
		logger.info("DropdownController.findCountries - Fetching countries");
		return new ResponseEntity<>(dropdownService.findCountries(), HttpStatus.OK);
	}

	@GetMapping("/getStates")
	public ResponseEntity<List<String>> findStates(@Param("country") String country) {
		logger.info("DropdownController.findStates - Fetching states for country: {}", country);
		return new ResponseEntity<>(dropdownService.findStates(country), HttpStatus.OK);
	}

	@GetMapping("/getDistrict")
	public ResponseEntity<List<String>> findDistrictes(@Param("state") String state) {
		return new ResponseEntity<>(dropdownService.findDistrictes(state), HttpStatus.OK);
	}

	@GetMapping("/getBanks")
	public ResponseEntity<List<String>> findBanks() {
		return new ResponseEntity<>(dropdownService.findBanks(), HttpStatus.OK);
	}

	@GetMapping("/getBankBranch")
	public ResponseEntity<List<String>> findBankBranches(@Param("bank") String bank) {
		return new ResponseEntity<>(dropdownService.findBankBranches(bank), HttpStatus.OK);
	}

	@GetMapping("/getEvidenceProof")
	public ResponseEntity<List<String>> findEvidenceProof() {
		return new ResponseEntity<>(dropdownService.findEvidenceProof(), HttpStatus.OK);
	}

	@GetMapping("/getOccupationCode")
	public ResponseEntity<List<String>> findOccupationCode() {
		return new ResponseEntity<>(dropdownService.findOccupationCode(), HttpStatus.OK);
	}

	@GetMapping("/getMaritalStatus")
	public ResponseEntity<List<String>> findMaritalStatus() {
		return new ResponseEntity<>(dropdownService.findMaritalStatus(), HttpStatus.OK);
	}

	@GetMapping("/getFamilyMemberType")
	public ResponseEntity<List<String>> findFamilyMemberType() {
		return new ResponseEntity<>(dropdownService.findFamilyMemberType(), HttpStatus.OK);
	}

	@GetMapping("/getBeneficiaryRelation")
	public ResponseEntity<List<String>> findBeneficiaryRelation() {
		return new ResponseEntity<>(dropdownService.findBeneficiaryRelation(), HttpStatus.OK);
	}

	@GetMapping("/getUwRequirementTypes")
	public ResponseEntity<List<String>> findTypesForUwRequirement() {
		return new ResponseEntity<>(dropdownService.findTypesForUwRequirement(), HttpStatus.OK);
	}

}
