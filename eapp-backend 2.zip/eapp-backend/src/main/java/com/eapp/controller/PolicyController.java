package com.eapp.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.dto.requestDTO.PolicySubmitRequestDTO;
import com.eapp.entity.Policy;
import com.eapp.service.PolicyService;

@RestController
@RequestMapping("/policy")
public class PolicyController {
    
    private static final Logger logger = LoggerFactory.getLogger(PolicyController.class);

    private final PolicyService policyService;

    public PolicyController(PolicyService policyService) {
        this.policyService = policyService;
    }

    @PostMapping("/submit")
    public Policy submitPolicy(@RequestBody PolicySubmitRequestDTO request) {
        logger.info("PolicyController.submitPolicy - Request received for policy: {}", request.getPolicyId());
        return policyService.submitPolicy(request);
    }
}
