package com.eapp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.dao.MVRtableRepos;
import com.eapp.dao.MasterLookupRepository;
import com.eapp.dao.MibTableRepos;
import com.eapp.dto.reponseDTO.CaseResponseDTO;
import com.eapp.dto.reponseDTO.MibFullDetailsDTO;
import com.eapp.dto.reponseDTO.MvrFullDetailsDTO;
import com.eapp.entity.CaseDetails;
import com.eapp.entity.MVRtable;
import com.eapp.entity.MasterLookup;
import com.eapp.entity.MibTable;
import com.eapp.service.UnderwritingService;

@RestController
@RequestMapping("/api/uw")
public class UnderwritingController {
    
    private static final Logger logger = LoggerFactory.getLogger(UnderwritingController.class);

    @Autowired
    private UnderwritingService service;
    
    @Autowired
    private MasterLookupRepository masterlookupRepository;
    
    @Autowired
    private MibTableRepos mibtableRepo;
    
    @Autowired
    private MVRtableRepos mVRtableRepos;

    // POST: http://localhost:8001/api/uw/save
    @PostMapping("/save")
    public ResponseEntity<CaseResponseDTO> postData(@RequestBody CaseDetails caseDetails) {
        logger.info("UnderwritingController.postData - Saving case details");
        return new ResponseEntity<>(service.saveFullCase(caseDetails), HttpStatus.CREATED);
    }

    // GET: http://localhost:8001/api/uw/fetch/1
    @GetMapping("/fetch/{id}")
    public ResponseEntity<CaseResponseDTO> getData(@PathVariable Long id) {
        logger.info("UnderwritingController.getData - Fetching case with ID: {}", id);
        return ResponseEntity.ok(service.getCase(id));
    }

    // GET ALL: http://localhost:8001/api/uw/fetchAll
    @GetMapping("/fetchAll")
    public ResponseEntity<List<CaseResponseDTO>> getAllData() {
        return ResponseEntity.ok(service.getAllCases());
    }

    // UPDATE: http://localhost:8001/api/uw/update/1
    @PutMapping("/update/{id}")
    public ResponseEntity<CaseResponseDTO> updateData(@PathVariable Long id, @RequestBody CaseDetails caseDetails) {
        logger.info("UnderwritingController.updateData - Updating case with ID: {}", id);
        return ResponseEntity.ok(service.updateCase(id, caseDetails));
    }

    // DELETE: http://localhost:8001/api/uw/delete/1
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteData(@PathVariable Long id) {
        logger.info("UnderwritingController.deleteData - Deleting case with ID: {}", id);
        service.deleteCase(id);
        return ResponseEntity.ok("Case deleted successfully for ID: " + id);
    }
    
 // GET ALL LOOKUPS: http://localhost:8001/api/uw/lookup/all
    @GetMapping("/lookup/all")
    public ResponseEntity<List<MasterLookup>> getAllLookups() {
        return ResponseEntity.ok(masterlookupRepository.findAll());
    }

    // GET LOOKUPS BY NAME: http://localhost:8001/api/uw/lookup/category/MIB
    @GetMapping("/lookup/category/{name}")
    public ResponseEntity<List<MasterLookup>> getLookupByCategory(@PathVariable String name) {
        return ResponseEntity.ok(masterlookupRepository.findByLookupName(name));
    }
 // SAVE Medical Record: http://localhost:8001/api/uw/mib/save
    @PostMapping("/mib/save")
    public ResponseEntity<MibTable> saveMib(@RequestBody MibTable mibEntry) {
        return new ResponseEntity<>(mibtableRepo.save(mibEntry), HttpStatus.CREATED);
    }

    // SAVE Driving Record: http://localhost:8001/api/uw/mvr/save
    @PostMapping("/mvr/save")
    public ResponseEntity<MVRtable> saveMvr(@RequestBody MVRtable mvrEntry) {
        return new ResponseEntity<>(mVRtableRepos.save(mvrEntry), HttpStatus.CREATED);
    }
    
// // GET medical history by SSN: http://localhost:8001/api/uw/mib/123-45-6789
//    @GetMapping("/mib/{ssn}")
//    public ResponseEntity<List<MibTable>> getMibBySsn(@PathVariable String ssn) {
//        return ResponseEntity.ok(mibtableRepo.findBySsn(ssn));
//    }
//    
// // GET driving history by DL: http://localhost:8001/api/uw/mvr/TX12345678
//    @GetMapping("/mvr/{dl}")
//    public ResponseEntity<List<MVRtable>> getMvrByDl(@PathVariable String dl) {
//        return ResponseEntity.ok(mVRtableRepos.findByDl(dl));
//    }
    
 // URL: http://localhost:8001/api/uw/mvr/{dl}
    @GetMapping("/mvr/{dl}")
    public ResponseEntity<MvrFullDetailsDTO> getMvrReport(@PathVariable String dl) {
        logger.info("UnderwritingController.getMvrReport - Fetching MVR report for DL: {}", dl);
        // 1. Get the list from the repository
        List<MvrFullDetailsDTO> reportList = mVRtableRepos.getDetailedMvrByDl(dl);
       
        if (reportList.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(reportList.get(0));
    }

    // URL: http://localhost:8001/api/uw/mib/{ssn}
    @GetMapping("/mib/{ssn}")
    public ResponseEntity<MibFullDetailsDTO> getMibReport(@PathVariable String ssn) {
        logger.info("UnderwritingController.getMibReport - Fetching MIB report for SSN: {}", ssn);
        List<MibFullDetailsDTO> reportList = mibtableRepo.getDetailedMibBySsn(ssn);
        
        if (reportList.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(reportList.get(0));
    }
}