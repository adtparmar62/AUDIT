package com.eapp.controller;
 
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.dto.requestDTO.RuleDefRequestDTO;
import com.eapp.entity.rule.Rule;
import com.eapp.service.rule.WorkWiseService;
 
@RestController
@RequestMapping("/eapp")
//@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3003"})
@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:3003" ,
		"http://internal-k8s-default-agenticu-dc7f68726f-1995427160.us-east-1.elb.amazonaws.com",
		"http://internal-k8s-default-agenticu-902b896a1f-1483840211.us-east-1.elb.amazonaws.com"
})
public class WorkWiseController {
	
	private static final Logger logger = LoggerFactory.getLogger(WorkWiseController.class);
	
	@Autowired
	private WorkWiseService workWiseService;
	
	@GetMapping("/getByWorkType")
	public ResponseEntity<List<Rule>> getByID(@Param("workCode") String workCode) {
		logger.info("WorkWiseController.getByID - Fetching rules for workCode: {}", workCode);
		return  new ResponseEntity<>(workWiseService.getAllRule(workCode),HttpStatus.OK);
	}

    @PostMapping("/setRuleDef")
    public ResponseEntity<String> setRuleDef(@RequestBody RuleDefRequestDTO req) {
        logger.info("WorkWiseController.setRuleDef - Setting rule definition for workCode: {}, quoteId: {}", req.getWorkCode(), req.getQuoteId());
        String role = workWiseService.setRuleDef(req.getWorkCode(), req.getQuoteId());
        return ResponseEntity.ok(role);
    }
 
}