package com.eapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.entity.CalculationRequest;
import com.eapp.service.CalculationService;

//@CrossOrigin(origins = "http://localhost:3000") // Example for a React/Vue frontend
@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:3003" ,
		"http://internal-k8s-default-agenticu-dc7f68726f-1995427160.us-east-1.elb.amazonaws.com",
		"http://internal-k8s-default-agenticu-902b896a1f-1483840211.us-east-1.elb.amazonaws.com"
})
@RestController
@RequestMapping("/api/calculator")
public class CalculationController {

    private final CalculationService calculationService;

    // Dependency Injection (constructor injection is preferred)
    @Autowired
    public CalculationController(CalculationService calculationService) {
        this.calculationService = calculationService;
    }

    // Define the POST endpoint for calculation
    @PostMapping("/calculate")
    public ResponseEntity<?> calculate(@RequestBody CalculationRequest request) {
        try {
            double result = calculationService.calculateValue(request);
            
            // Return the result with an HTTP 200 OK status
            return ResponseEntity.ok(
                java.util.Collections.singletonMap("finalValue", result)
            );
            
        } catch (IllegalArgumentException e) {
            // Handle bad input (e.g., invalid risk class) with HTTP 400 Bad Request
            return ResponseEntity.badRequest().body(
                java.util.Collections.singletonMap("error", e.getMessage())
            );
        } catch (Exception e) {
            // Handle other server errors with HTTP 500 Internal Server Error
            return ResponseEntity.internalServerError().body(
                java.util.Collections.singletonMap("error", "An unexpected error occurred during calculation.")
            );
        }
    }
}