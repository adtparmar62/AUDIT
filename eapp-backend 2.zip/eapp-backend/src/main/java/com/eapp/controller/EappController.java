package com.eapp.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.dao.UwPolicySummary;
import com.eapp.dto.requestDTO.AgentRequestDTO;
import com.eapp.entity.QuoteDetails;
import com.eapp.entity.UwPolicy;
import com.eapp.service.EappService;





@RestController
@RequestMapping("/eapp")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3003"})
public class EappController {
	
	private final Logger logger =LoggerFactory.getLogger(EappController.class);
	
	@Autowired
	private EappService eappService;

    @PostMapping("/addQuote")
    public ResponseEntity<QuoteDetails> addQuote(@RequestBody QuoteDetails eapp){
        return new ResponseEntity<QuoteDetails>(eappService.addQuote(eapp), HttpStatus.CREATED);
    }
	
	@PostMapping("/add")
	public ResponseEntity<QuoteDetails> create(@RequestBody QuoteDetails eapp) {
		
		logger.info("Start"); 
		logger.debug("Eapp details"+ eapp);
		System.out.println("Data => " + eapp);
		logger.info("End");
		 
		return new ResponseEntity<>(eappService.create(eapp), HttpStatus.CREATED);
	}
	
	@PostMapping("/update")
	public ResponseEntity<QuoteDetails> update(@RequestBody QuoteDetails eapp) {
		logger.info("Start"); 
		logger.debug("Eapp details"+ eapp);
		logger.info("End");
		 
		return new ResponseEntity<>(eappService.update(eapp),HttpStatus.OK);
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Map<String, Object>>> findAll() {
		return new ResponseEntity<>(eappService.getAll(), HttpStatus.OK);
	}

    @GetMapping("/getAllUw")
    public ResponseEntity<List<UwPolicy>> findAllUw() {
        return new ResponseEntity<>(eappService.getAllUw(),HttpStatus.OK);
    }

    @GetMapping("/getAllUwSummary")
    public ResponseEntity<List<UwPolicySummary>> findAllUwSummary() {
        return new ResponseEntity<>(eappService.getAllUwSummary(), HttpStatus.OK);
    }
    @GetMapping("/getUwByQuoteId")
    public ResponseEntity<UwPolicy> getUwByQuoteId(@Param("id") String id){
        return new ResponseEntity<UwPolicy>(eappService.getUwByQuoteId(id), HttpStatus.OK);
    }

	@GetMapping("/getByID")
	public ResponseEntity<QuoteDetails> getByID(@Param("id") int id) {
		return  new ResponseEntity<>(eappService.getEappDetailsById(id),HttpStatus.OK);
	}
	
	@GetMapping("/getCaseDetailsByQuotoIdAndScreenNo")
	public ResponseEntity<QuoteDetails> getCaseDetailsByQuotoIdAndScreenNo(
			@Param("quoationId") String quoationId,@Param("screenNo") int screenNo) {
		return  new ResponseEntity<>(eappService.getCaseDetailsByQuotoIdAndScreenNo(quoationId, screenNo),HttpStatus.OK);
	}

    @PostMapping("/generateQuoteId")
    public ResponseEntity<String> generateQuoteId(){
        return  new ResponseEntity<>(eappService.generateQuoteId(),HttpStatus.OK);
    }
    
    @GetMapping("/pullQuote")
    public void pullQuote() {
    	eappService.pullQuote();
        //return new ResponseEntity<>(,HttpStatus.OK);
    }

    @PostMapping(value = "/getAgentResponse", produces = "application/json")
    public ResponseEntity<String> getAgentResponse(@RequestBody AgentRequestDTO request) {
        logger.info("Start getAgentResponse");
        logger.debug("Request details: quotation_no=" + request.getQuotation_no() + ", agent=" + request.getAgent());

        if (request.getQuotation_no() == null || request.getAgent() == null) {
            return new ResponseEntity<>("{\"error\": \"quotation_no and agent are required\"}", HttpStatus.BAD_REQUEST);
        }

        String responseJson = eappService.getAgentResponse(request.getQuotation_no(), request.getAgent());

        logger.info("End getAgentResponse");

        if (responseJson != null) {
            return new ResponseEntity<>(responseJson, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("{\"message\": \"No response found for given criteria\"}", HttpStatus.NOT_FOUND);
        }
    }
    
}
