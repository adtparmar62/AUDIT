package com.eapp.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.dto.reponseDTO.UserAuthResponseDTO;
import com.eapp.dto.reponseDTO.UserResponseDTO;
import com.eapp.dto.requestDTO.UserRequestDTO;
import com.eapp.enums.Role;
import com.eapp.security.JwtUtil;
import com.eapp.service.UserService;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:3003" ,
		"http://internal-k8s-default-agenticu-dc7f68726f-1995427160.us-east-1.elb.amazonaws.com",
		"http://internal-k8s-default-agenticu-902b896a1f-1483840211.us-east-1.elb.amazonaws.com"
})
public class UserAuthController {
	
	private static final Logger logger = LoggerFactory.getLogger(UserAuthController.class);

    private final UserService userService;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;

    public UserAuthController(UserService userService,
                              JwtUtil jwtUtil,
                              AuthenticationManager authenticationManager,
                              PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.jwtUtil = jwtUtil;
        this.authenticationManager = authenticationManager;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/signup")
    public ResponseEntity<UserResponseDTO> signup(@RequestBody UserRequestDTO userRequestDTO) {
        logger.info("UserAuthController.signup - Signup request for email: {}", userRequestDTO.getEmail());
        // Encrypt password before saving
        userRequestDTO.setPassword(passwordEncoder.encode(userRequestDTO.getPassword()));

        UserResponseDTO response =  userService.signup(userRequestDTO);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<UserAuthResponseDTO> login(@RequestBody UserRequestDTO userRequestDTO) {
        logger.info("UserAuthController.login - Login request for email: {}", userRequestDTO.getEmail());
        UserResponseDTO response = userService.login(userRequestDTO);

        // Generate JWT token after successful login
        String token = jwtUtil.generateToken(response.getEmail(),response.getFirstName(),response.getLastName(), Role.ADMIN);

        UserAuthResponseDTO res = new UserAuthResponseDTO(token);

        return ResponseEntity.ok(res);
    }
}