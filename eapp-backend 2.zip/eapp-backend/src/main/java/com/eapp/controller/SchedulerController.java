package com.eapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eapp.scheduler.SchedulerService;

@RestController
@RequestMapping("/eapp/scheduler")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:3003"})
public class SchedulerController {

    @Autowired
    private SchedulerService schedulerService;

    /**
     * Called when frontend switches to Batch Mode.
     * Pauses the cron job so it stops firing automatically.
     */
    @PostMapping("/disable")
    public ResponseEntity<String> disableScheduler() {
        schedulerService.disable();
        return new ResponseEntity<>("{\"message\": \"Scheduler disabled successfully\"}", HttpStatus.OK);
    }

    /**
     * Called when frontend switches back to Auto Trigger mode.
     * Resumes the cron job.
     */
    @PostMapping("/enable")
    public ResponseEntity<String> enableScheduler() {
        schedulerService.enable();
        return new ResponseEntity<>("{\"message\": \"Scheduler enabled successfully\"}", HttpStatus.OK);
    }
}