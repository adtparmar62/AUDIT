package com.eapp.enums;

public enum Role {
    ADMIN,
    Sr_UW,
    UW,
    Jr_UW,
    Case_Manager,
    User
}
