package com.eapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.eapp.dao.UwPolicyRepository;
import com.eapp.entity.UwPolicy;

@Service
public class UwPolicyService {

    private static final Logger logger = LoggerFactory.getLogger(UwPolicyService.class);

    @Autowired
    private UwPolicyRepository uwPolicyRepository;

    private final RestTemplate restTemplate;

    public UwPolicyService() {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(10_000);
        factory.setReadTimeout(900_000); // 15 min — agent calls can be long
        restTemplate = new RestTemplate(factory);
    }

    // Inject values from application.properties
    @Value("${lambda.url.status3}")
    private String lambdaForStatus3;

    @Value("${lambda.url.status6}")
    private String lambdaForStatus6;

    @Value("${lambda.url.status8}")
    private String lambdaForStatus8;

    public void processAutoToManualPolicies() {
        // logger.info("UwPolicyService.processAutoToManualPolicies - Starting cron job");
        List<UwPolicy> status3Policies = uwPolicyRepository.findPendingManualPolicies();
        List<UwPolicy> status8Policies = uwPolicyRepository.findPendingManualPoliciesWithStatus8();
        List<UwPolicy> status6Policies = uwPolicyRepository.findPendingManualPoliciesWithStatus6();

        List<UwPolicy> pendingPolicies = new ArrayList<>();
        pendingPolicies.addAll(status3Policies);
        pendingPolicies.addAll(status6Policies);
        pendingPolicies.addAll(status8Policies);

        if (pendingPolicies.isEmpty()) {
            // logger.info("UwPolicyService.processAutoToManualPolicies - No policies found to process");
            return;
        }

        // Deduplicate: t_uw_policy can have multiple rows per policy_id.
        // Keep only the latest row (highest uw_id) per policy so we never
        // fire multiple agent calls for the same policy in one cron tick.
        Map<String, UwPolicy> uniqueByPolicyId = new java.util.LinkedHashMap<>();
        for (UwPolicy p : pendingPolicies) {
            uniqueByPolicyId.merge(p.getPolicyId(), p,
                (existing, candidate) -> candidate.getUwid() > existing.getUwid() ? candidate : existing);
        }
        List<UwPolicy> dedupedPolicies = new ArrayList<>(uniqueByPolicyId.values());

        logger.info("UwPolicyService.processAutoToManualPolicies - Found {} unique policies to process (raw: {})",
            dedupedPolicies.size(), pendingPolicies.size());

        for (UwPolicy policy : dedupedPolicies) {
            processSinglePolicy(policy);
        }

        // logger.info("UwPolicyService.processAutoToManualPolicies - Cron job finished");
    }

    private void processSinglePolicy(UwPolicy policy) {
        logger.info("UwPolicyService.processSinglePolicy - Processing policy: {}, status: {}", policy.getPolicyId(), policy.getStateId());
        try {
            String lambdaUrl;
            int nextStatus;

            switch (policy.getStateId()) {
                case 3:
                    // logger.info("UwPolicyService.processSinglePolicy - Policy status 3, using lambda for status 3");
                    lambdaUrl = lambdaForStatus3; // use injected property
                    nextStatus = 6;
                    break;
                case 7:
                    // logger.info("UwPolicyService.processSinglePolicy - Policy status 7, using lambda for status 6");
                    lambdaUrl = lambdaForStatus6; // use injected property
                    nextStatus = 8;
                    break;
                case 9:
                    // logger.info("UwPolicyService.processSinglePolicy - Policy status 9, using lambda for status 8");
                    lambdaUrl = lambdaForStatus8; // use injected property
                    nextStatus = 10;
                    break;
                default:
                    logger.warn("UwPolicyService.processSinglePolicy - Skipping policy {} with unsupported status: {}", policy.getPolicyId(), policy.getStateId());
                    return;
            }

//            String url = null;
//
//            if (isLocal()) {
//                url = UriComponentsBuilder.fromHttpUrl(lambdaUrl)
//                        .queryParam("quoteId", policy.getPolicyId())
//                        .queryParam("agentId", policy.getStateId())
//                        .toUriString();
//            }
//            else {
//                url = UriComponentsBuilder.fromHttpUrl(lambdaUrl)
//                    .queryParam("quoteId", policy.getPolicyId())
//                    .toUriString();
//            }


            String url = UriComponentsBuilder.fromHttpUrl(lambdaUrl)
                    .queryParam("quoteId", policy.getPolicyId())
                    .toUriString();
            logger.info("URL ******************* => " + url);
            // logger.info("quoteId ******************* => " + policy.getPolicyId());

            // Advance status before calling lambda so the cron does not re-pick
            // this policy while the long-running agent is still processing.
            policy.setStateId(nextStatus);
            uwPolicyRepository.save(policy);
            logger.info("UwPolicyService.processSinglePolicy - Pre-advanced policy {} to uw_status = {}", policy.getPolicyId(), nextStatus);

            // Fire lambda asynchronously — status is already advanced so cron won't re-pick.
            // This keeps the "In Progress" status visible in the UI until the lambda sets "Completed".
            final String finalUrl = url;
            final String policyId = policy.getPolicyId();
            new Thread(() -> {
                try {
                    ResponseEntity<String> response = restTemplate.postForEntity(finalUrl, null, String.class);
                    if (response.getStatusCode().is2xxSuccessful()) {
                        logger.info("UwPolicyService.processSinglePolicy - Lambda call completed successfully for policy {}", policyId);
                    } else {
                        logger.error("UwPolicyService.processSinglePolicy - Policy {} lambda returned non-2xx: {}", policyId, response.getStatusCode());
                    }
                } catch (Exception ex) {
                    logger.error("UwPolicyService.processSinglePolicy - Async lambda call failed for policy {}: {}", policyId, ex.getMessage(), ex);
                }
            }).start();

        } catch (Exception e) {
            logger.error("UwPolicyService.processSinglePolicy - Failed to process policy {}: {}", policy.getPolicyId(), e.getMessage(), e);
            e.printStackTrace();
        }
        // logger.info("UwPolicyService.processSinglePolicy - Finished processing policy: {}", policy.getPolicyId());
    }
    
}
