package com.eapp.service;

import org.springframework.stereotype.Service;

import com.eapp.entity.CalculationRequest;

@Service
public class CalculationService {

    public double calculateValue(CalculationRequest request) {
        
        // 1. Determine the Risk Multiplier
        double riskMultiplier = getRiskMultiplier(request.getRiskClass());
        
        // 2. Base Formula Calculation: tp + tp*Em/500 + tp*permile/1000
        double tp = request.getTp();
        double em = request.getEm();
        double permile = request.getPermile();
        
        double baseResult = tp + 
                            (tp * em / 500.0) + 
                            (tp * permile / 1000.0);
        
        // 3. Apply Class Multipliers
        int occupationClass = request.getOccupationClass();
        
        // Final Value = Risk Multiplier * Occupation Class * Base Result
        double finalValue = riskMultiplier * occupationClass * baseResult;
        
        return finalValue;
    }

    private double getRiskMultiplier(String riskClass) {
        // Use a switch expression for clean mapping
        return switch (riskClass.toLowerCase()) {
            case "low" -> 2.0;
            case "mid" -> 4.0;
            case "high" -> 6.0;
            default -> throw new IllegalArgumentException("Invalid risk class: " + riskClass);
        };
    }
}