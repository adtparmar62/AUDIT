package com.eapp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eapp.dao.PolicyRepository;
import com.eapp.entity.Policy;

@Service
public class RoleBasedAccessImpl implements RoleBasedAccess{
	
	private static final Logger logger = LoggerFactory.getLogger(RoleBasedAccessImpl.class);
	
	@Autowired
	private PolicyRepository policyRepository;
	
	public List<Policy> isAccessableApplication(String email){
		logger.info("RoleBasedAccessImpl.isAccessableApplication - Fetching accessible applications for email: {}", email);
		return policyRepository.findPoliciesByRoleEmail(email);
	}

	@Override
	public List<Policy> isAccessableProofing(String email) {
		logger.info("RoleBasedAccessImpl.isAccessableProofing - Fetching accessible proofing for email: {}", email);
		return policyRepository.findPoliciesByRoleEmailProofing(email);
	}

	
	
	

}
