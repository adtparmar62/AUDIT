package com.eapp.service.rule;

import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eapp.dao.PolicyRepository;
import com.eapp.dao.UwPolicyRepository;
import com.eapp.dao.WorkRepos;
import com.eapp.entity.Policy;
import com.eapp.entity.QuoteDetails;
import com.eapp.entity.UwPolicy;
import com.eapp.entity.rule.Rule;
import com.eapp.entity.rule.RuleDef;

@Service
public class WorkWiseServiceImpl implements WorkWiseService {
    
    private static final Logger logger = LoggerFactory.getLogger(WorkWiseServiceImpl.class);

    private final WorkRepos workRepos;
    private final PolicyRepository policyRepository;
    private final UwPolicyRepository uwPolicyRepository;

    public WorkWiseServiceImpl(WorkRepos workRepos,
                               PolicyRepository policyRepository,
                               UwPolicyRepository uwPolicyRepository) {
        this.workRepos = workRepos;
        this.policyRepository = policyRepository;
        this.uwPolicyRepository = uwPolicyRepository;
    }

    @Override
    public List<Rule> getAllRule(String work) {
        // logger.info("WorkWiseServiceImpl.getAllRule - Fetching rules for work: {}", work);
        return workRepos.findById(work)
                .orElseThrow(() -> new RuntimeException("Work type not found: " + work))
                .getRules();
    }

    @Override
    @Transactional
    public String setRuleDef(String workCode, String quoteId) {
        // logger.info("WorkWiseServiceImpl.setRuleDef - Setting rule definition for workCode: {}, quoteId: {}", workCode, quoteId);
        List<Rule> allRule = getAllRule(workCode);
        Policy policy = policyRepository.findById(quoteId)
                .orElseThrow(() -> new RuntimeException("Policy not found: " + quoteId));

        // resolve role based on rules/validation
        String resolvedRole = resolveRole(policy, allRule);

        // dump into UW table
        dumpDataIntoUWPolicy(policy, resolvedRole);

        // persist role assignment on policy
        policy.setAssignRole(resolvedRole);
        policy.setUpdateTime(LocalDateTime.now());
        policyRepository.save(policy);
        logger.info("WorkWiseServiceImpl.setRuleDef - Rule definition set successfully, resolved role: {}", resolvedRole);

        return resolvedRole;
    }

    private String resolveRole(Policy policy, List<Rule> allRule) {
        String role = "R001"; // default
        for (Rule rule : allRule) {
            if (rule.getAssignTo() != null && rule.getAssignTo().getRoleCode() != null) {
                role = rule.getAssignTo().getRoleCode();
                break;
            } else if (rule.getValidation() != null) {
                role = checkValidationRule(policy, rule.getValidation());
            }
        }
        return role;
    }

    private String checkValidationRule(Policy policy, RuleDef validation) {
        if ("VRule_005".equals(validation.getRuleCode())) {
            return checkRuleVR005(policy);
        }
        return "R001";
    }

    private String checkRuleVR005(Policy policy) {
        if (policy.getNormalPrem() > 10000) {
            return "R002";
        } else if (policy.getNormalPrem() > 5000) {
            return "R003";
        } else {
            return "R004";
        }
    }

    private void dumpDataIntoUWPolicy(Policy policy, String role) {
        // logger.info("WorkWiseServiceImpl.dumpDataIntoUWPolicy - Dumping data into UW policy for policy: {}", policy.getPolicyId());
        String pid = policy.getPolicyId();
//        System.out.println(policy.getPolicyId());
        String productName = new QuoteDetails().getValueFromJson("Product");

        UwPolicy uw = new UwPolicy();
        uw.setPolicyId(pid);
        uw.setNormalPrem(policy.getNormalPrem());
        uw.setPeriodPrem(policy.getPeriodPrem());
        uw.setSa(policy.getSa());
        uw.setUnderwriterId(role);
        uw.setStateId(policy.getStateId());
        uw.setProduct(productName);
        uwPolicyRepository.save(uw);
        // logger.info("WorkWiseServiceImpl.dumpDataIntoUWPolicy - Data dumped successfully into UW policy");
    }
}
