package com.eapp.service;

import java.util.List;

import com.eapp.dto.reponseDTO.UserResponseDTO;
import com.eapp.dto.requestDTO.UserRequestDTO;

public interface UserService {
    UserResponseDTO createUser(UserRequestDTO userRequestDTO);
    UserResponseDTO getUserByEmail(String email);
    List<UserResponseDTO> getAllUsers();
    void deleteUser(String email);
    UserResponseDTO signup(UserRequestDTO userRequestDTO);
    UserResponseDTO login(UserRequestDTO userRequestDTO);
}
