package com.eapp.service;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.eapp.dao.AddressRepos;
import com.eapp.dao.CaseDetailsRepos;
import com.eapp.dao.CoverageFieldsRepos;
import com.eapp.dao.CoverageRepos;
import com.eapp.dao.PartyRepos;
import com.eapp.dao.PolicyRepository;
import com.eapp.dao.QuoteDetailsRepos;
import com.eapp.dto.requestDTO.PolicySubmitRequestDTO;
import com.eapp.entity.Address;
import com.eapp.entity.CaseDetails;
import com.eapp.entity.Party;
import com.eapp.entity.Policy;
import com.eapp.entity.QuoteDetails;

import jakarta.transaction.Transactional;

@Service
public class PolicyService {
    
    private static final Logger logger = LoggerFactory.getLogger(PolicyService.class);

    private final PolicyRepository policyRepository;
    private final QuoteDetailsRepos quoteDetailsRepos;
    
    private final CoverageRepos coverageRepos;
    private final CoverageFieldsRepos coverageFieldsRepos;
    private final PartyRepos partyRepos;
    private final CaseDetailsRepos caseDetailsRepos;
    private final AddressRepos addressRepos;

    public PolicyService(PolicyRepository policyRepository,
    		QuoteDetailsRepos quoteDetailsRepos,
    		CoverageRepos coverageRepos,
    		CoverageFieldsRepos coverageFieldsRepos,
    		PartyRepos partyRepos,
    		AddressRepos addressRepos,
    		CaseDetailsRepos caseDetailsRepos
    		) {
        this.policyRepository = policyRepository;
        this.quoteDetailsRepos=quoteDetailsRepos;
        this.coverageRepos =coverageRepos;
        this.coverageFieldsRepos =coverageFieldsRepos;
        this.partyRepos=partyRepos;
        this.addressRepos =addressRepos;
        this.caseDetailsRepos=caseDetailsRepos;
       
    }
    @Transactional
    public Policy submitPolicy(PolicySubmitRequestDTO request) {
        logger.info("PolicyService.submitPolicy - Submitting policy: {}", request.getPolicyId());
        Policy policy = policyRepository.findById(request.getPolicyId() )
                .orElseThrow(() -> new RuntimeException("Policy not found"));
//        Optional<QuoteDetails> screen1Details = quoteDetailsRepos.findDetailsWithLatestVersionNo(request.getPolicyId(), 1);
//        Optional<QuoteDetails> screen2Details = quoteDetailsRepos.findDetailsWithLatestVersionNo(request.getPolicyId(), 2);

        // Update fields
        policy.setStateId(3); // move to Proofing
//        policy.setSa( Double.parseDouble(screen2Details.get().getSumAssured()));
//        policy.setPeriodPrem(Double.parseDouble(screen2Details.get().getPremiumAmount()));
//        policy.setNormalPrem(Double.parseDouble(screen2Details.get().getInstallmentPremium()));
//        policy.setProductName(screen2Details.get().getProductName());
//        policy.setHolderName(screen1Details.get().getProspectName());
        policy.setUpdateTime(LocalDateTime.now());
        
        //moveDataToUnderWriting();
        QuoteDetails quoteDetails = new QuoteDetails();
        
        quoteDetails.setQuotation_id(request.getPolicyId());
        quoteDetails.setJSON_DATA(request.getJsonData());
        quoteDetailsRepos.save(quoteDetails);
        logger.info("PolicyService.submitPolicy - Policy submitted successfully: {}", request.getPolicyId());
        return policyRepository.save(policy);
    }
	
    
    
    private void moveDataToUnderWriting() {
		Address address = new Address();
		CaseDetails caseDetails = new CaseDetails();
		Party party = new Party();
		
		address.setAddressLine1(null);
		address.setAddressLine2("B");
		address.setAddressLine3("A");
		address = addressRepos.save(address);
		
		caseDetails.setCaseStatus("3");
		caseDetails.setIssueDate(null);
		caseDetails.setMarketName(null);
		caseDetails.setQuotationId(null);
		
		party.setAddressId(address.getAddressId());
		party.setCaseDetails(caseDetails);
		party.setDateOfBirth(null);
		party.setFullName(null);
		
		
	}
}