package com.eapp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eapp.dao.DropdownDetailsRepos;

@Service
public class DropdownServiceImpl implements DropdownService {
	
	private static final Logger logger = LoggerFactory.getLogger(DropdownServiceImpl.class);

	@Autowired
	private DropdownDetailsRepos dropdownDetailsRepos;

	@Override
	public List<String> findCountries() {
		logger.info("DropdownServiceImpl.findCountries - Fetching countries from DB");
		return dropdownDetailsRepos.findCountries();
	}

	@Override
	public List<String> findStates(String country) {
		logger.info("DropdownServiceImpl.findStates - Fetching states for country: {}", country);
		return dropdownDetailsRepos.findStates(country);
	}

	@Override
	public List<String> findDistrictes(String state) {
		logger.info("DropdownServiceImpl.findDistrictes - Fetching districts for state: {}", state);
		return dropdownDetailsRepos.findDistrictes(state);
	}

	@Override
	public List<String> findBanks() {
		logger.info("DropdownServiceImpl.findBanks - Fetching banks from DB");
		return dropdownDetailsRepos.findBanks();
	}

	@Override
	public List<String> findBankBranches(String bank) {
		logger.info("DropdownServiceImpl.findBankBranches - Fetching branches for bank: {}", bank);
		return dropdownDetailsRepos.findBankBranches(bank);
	}

	@Override
	public List<String> findEvidenceProof() {
		return dropdownDetailsRepos.findEvidenceProof();
	}

	@Override
	public List<String> findOccupationCode() {
		return dropdownDetailsRepos.findOccupationCode();
	}

	@Override
	public List<String> findMaritalStatus() {
		return dropdownDetailsRepos.findMaritalStatus();
	}

	@Override
	public List<String> findFamilyMemberType() {
		return dropdownDetailsRepos.findFamilyMemberType();
	}

	@Override
	public List<String> findBeneficiaryRelation() {
		return dropdownDetailsRepos.findBeneficiaryRelation();
	}

	@Override
	public List<String> findTypesForUwRequirement() {
		return dropdownDetailsRepos.findTypesForUwRequirement();
	}

}
