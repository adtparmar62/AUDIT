package com.eapp.service.rule;
 
import java.util.List;

import com.eapp.entity.rule.Rule;
 
public interface WorkWiseService {
	
	List<Rule> getAllRule(String work);

    public String setRuleDef(String workCode, String quoteId);



}