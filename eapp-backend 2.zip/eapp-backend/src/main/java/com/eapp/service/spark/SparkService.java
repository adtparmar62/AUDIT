package com.eapp.service.spark;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eapp.dao.RequestMetaRepository;
import com.eapp.dao.UwPolicyRepository;
import com.eapp.dto.SparkPolicyResult;
import com.eapp.entity.UwPolicy;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;

@Service
public class SparkService {

    private static final Logger logger = LoggerFactory.getLogger(SparkService.class);

    private final UwPolicyRepository uwPolicyRepository;
    private final RequestMetaRepository metaRepo;
    private final SparkTokenService sparkTokenService;
    private final Gson gson = new Gson();

    @Value("${spark.api.url}")
    private String sparkApiUrl;

    @Value("${http.client.connect.timeout:5}")
    private int connectTimeoutSeconds;

    @Value("${http.client.read.timeout:30}")
    private int readTimeoutSeconds;

    public SparkService(RequestMetaRepository metaRepo,
                        UwPolicyRepository uwPolicyRepository,
                        SparkTokenService sparkTokenService) {
        this.metaRepo = metaRepo;
        this.uwPolicyRepository = uwPolicyRepository;
        this.sparkTokenService = sparkTokenService;
    }

    @Transactional
    public ResponseEntity<List<SparkPolicyResult>> triggerAutoUWForPolicy(String policyId) {
        logger.info("SparkService.triggerAutoUWForPolicy - Triggering SPARK for single policyId={}", policyId);

        List<SparkPolicyResult> results = new ArrayList<>();

        Optional<UwPolicy> latestWithContentOpt = uwPolicyRepository
                .findTopByPolicyIdAndContentIsNotNullOrderByUwidDesc(policyId);

        if (latestWithContentOpt.isEmpty()) {
            logger.warn("SparkService.triggerAutoUWForPolicy - No content found for policyId={}", policyId);
            results.add(new SparkPolicyResult(policyId, null, null));
            return ResponseEntity.ok(results);
        }

        UwPolicy policy = latestWithContentOpt.get();
        String content = policy.getContent();

        try {
            JsonObject contentJson = gson.fromJson(content, JsonObject.class);
            JsonObject inputs = buildInputsFromContent(contentJson);

            RequestData requestData = new RequestData();
            requestData.setInputs(inputs);

            RequestMeta meta = metaRepo.fetchOne();

            Request request = new Request();
            request.request_data = requestData;
            request.request_meta = meta;

            String jsonBody = gson.toJson(request);
            logger.debug("SparkService.triggerAutoUWForPolicy - Request body: {}", jsonBody);

            String sparkOutput = callSpark(jsonBody);

            policy.setOutputData(sparkOutput);
            policy.setStateId(3);
            uwPolicyRepository.save(policy);

            logger.info("SparkService.triggerAutoUWForPolicy - SPARK call successful for policyId={}", policyId);
            results.add(new SparkPolicyResult(policyId, policy.getUwid(), sparkOutput));

        } catch (Exception ex) {
            logger.error("SparkService.triggerAutoUWForPolicy - SPARK call failed for policyId={}: {}",
                    policyId, ex.getMessage(), ex);
            String err = String.format(
                    "{\"error\":\"SPARK call failed for policyId %s\",\"message\":\"%s\"}",
                    policyId, ex.getMessage());
            results.add(new SparkPolicyResult(policyId, policy.getUwid(), err));
        }

        return ResponseEntity.ok(results);
    }

    @Transactional
    public ResponseEntity<List<SparkPolicyResult>> triggerAutoUWBatchAll() {
        logger.info("SparkService.triggerAutoUWBatchAll - Triggering auto UW batch for all policies");
        List<String> policyIds = uwPolicyRepository.findDistinctPolicyIdsAll();

        List<SparkPolicyResult> results = new ArrayList<>();

        for (String policyId : policyIds) {
            logger.info("SparkService.triggerAutoUWBatchAll - Processing policy: {}", policyId);
            Optional<UwPolicy> latestWithContentOpt = uwPolicyRepository
                    .findTopByPolicyIdAndContentIsNotNullOrderByUwidDesc(policyId);

            if (latestWithContentOpt.isEmpty()) {
                logger.warn("SparkService.triggerAutoUWBatchAll - No content found for policy: {}", policyId);
                results.add(new SparkPolicyResult(policyId, null, null));
                continue;
            }

            UwPolicy policy = latestWithContentOpt.get();
            String content = policy.getContent();

            try {
                JsonObject contentJson = gson.fromJson(content, JsonObject.class);
                JsonObject inputs = buildInputsFromContent(contentJson);

                RequestData requestData = new RequestData();
                requestData.setInputs(inputs);

                RequestMeta meta = metaRepo.fetchOne();

                Request request = new Request();
                request.request_data = requestData;
                request.request_meta = meta;

                String jsonBody = gson.toJson(request);
                System.out.println("---SPARK---");
                System.out.println(jsonBody);

                String sparkOutput = callSpark(jsonBody);

                policy.setOutputData(sparkOutput);
                policy.setStateId(3);
                uwPolicyRepository.save(policy);
                logger.info("SparkService.triggerAutoUWBatchAll - SPARK call successful for policy: {}", policyId);

                results.add(new SparkPolicyResult(policyId, policy.getUwid(), sparkOutput));
            } catch (Exception ex) {
                logger.error("SparkService.triggerAutoUWBatchAll - SPARK call failed for policy {}: {}",
                        policyId, ex.getMessage(), ex);
                ex.printStackTrace();
                String err = String.format(
                        "{\"error\":\"SPARK call failed for policyId %s\",\"message\":\"%s\"}",
                        policyId, ex.getMessage());
                results.add(new SparkPolicyResult(policyId, policy.getUwid(), err));
            }
        }
        logger.info("SparkService.triggerAutoUWBatchAll - Batch processing completed");

        return ResponseEntity.ok(results);
    }

    private JsonObject buildInputsFromContent(JsonObject contentJson) {
        JsonObject inputs = new JsonObject();

        JsonObject lifeAssured = obj(contentJson.get("lifeAssured"));
        JsonObject planDetails = obj(contentJson.get("planDetails"));
        JsonObject healthDetails = obj(contentJson.get("healthDetails"));

        Integer age = asInt(lifeAssured.get("insuredAge"));
        Integer height = asInt(healthDetails.get("height"));
        Integer weight = asInt(healthDetails.get("weight"));
        Integer si = asInt(planDetails.get("basicSumInsured"));
        Integer income = asInt(lifeAssured.get("annualIncome"));

        String alcohol = asString(healthDetails.get("alcoholConsumption"));
        String family = asString(healthDetails.get("familyHistory"));
        String gender = asString(lifeAssured.get("insuredGender"));
        String healthI = asString(healthDetails.get("healthImpairments"));
        String lifestyle = asString(lifeAssured.get("lifestyle"));
        String medI = asString(healthDetails.get("medicalImpairments"));
        String mental = asString(healthDetails.get("mentalHealthHistory"));
        String occu = asString(lifeAssured.get("occupation"));
        String smoker = asString(healthDetails.get("smokingStatus"));
        String travel = asString(lifeAssured.get("travel"));

        addNumberOrNull(inputs, "Age", age);
        addStringOrNull(inputs, "Alcohol_con", alcohol);
        addStringOrNull(inputs, "Family_His", family);
        addStringOrNull(inputs, "Gender", gender);
        addStringOrNull(inputs, "Health_I", healthI);
        addNumberOrNull(inputs, "Height", height);
        addNumberOrNull(inputs, "Income", income);
        addStringOrNull(inputs, "LifeStyl", lifestyle);
        addStringOrNull(inputs, "Med_I", medI);
        addStringOrNull(inputs, "Mental_his", mental);
        addStringOrNull(inputs, "Occu", occu);
        addNumberOrNull(inputs, "SI", si);
        addStringOrNull(inputs, "Smoker", smoker);
        addStringOrNull(inputs, "Travel", travel);
        addNumberOrNull(inputs, "Weight", weight);

        return inputs;
    }

    private String callSpark(String jsonBody) throws Exception {
        logger.info("SparkService.callSpark - Calling SPARK API");
        HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(connectTimeoutSeconds))
                .build();

        String token = sparkTokenService.getValidToken();
        if (token == null || token.isEmpty()) {
            throw new IllegalStateException("Missing spark.api.token");
        }

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(sparkApiUrl))
                .timeout(Duration.ofSeconds(readTimeoutSeconds))
                .header("Authorization", "Bearer " + token)
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

        HttpResponse<String> resp = client.send(request, HttpResponse.BodyHandlers.ofString());
        int status = resp.statusCode();
        if (status >= 200 && status < 300) {
            return resp.body();
        }
        throw new RuntimeException("SPARK HTTP " + status + " : " + (resp.body() == null ? "" : resp.body()));
    }

    private JsonObject obj(JsonElement e) {
        return (e != null && e.isJsonObject()) ? e.getAsJsonObject() : new JsonObject();
    }

    private String asString(JsonElement e) {
        return (e == null || e.isJsonNull()) ? null : e.getAsString().trim();
    }

    private Integer asInt(JsonElement e) {
        if (e == null || e.isJsonNull()) return null;
        try {
            String s = e.getAsString().trim();
            if (s.isEmpty()) return null;
            return (int) Math.round(Double.parseDouble(s));
        } catch (Exception ex) {
            return null;
        }
    }

    private void addStringOrNull(JsonObject o, String key, String val) {
        o.add(key, val == null ? JsonNull.INSTANCE : gson.toJsonTree(val));
    }

    private void addNumberOrNull(JsonObject o, String key, Number val) {
        o.add(key, val == null ? JsonNull.INSTANCE : gson.toJsonTree(val));
    }
}
