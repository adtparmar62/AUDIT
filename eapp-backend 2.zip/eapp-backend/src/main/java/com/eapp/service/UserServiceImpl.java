package com.eapp.service;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.eapp.dao.RoleBasedAccessRepository;
import com.eapp.dao.UserRepository;
import com.eapp.dto.reponseDTO.UserResponseDTO;
import com.eapp.dto.requestDTO.UserRequestDTO;
import com.eapp.entity.User;
import com.eapp.entity.role.Role;


@Service
public class UserServiceImpl implements UserService {
    
    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    public static final  String defaultRoleCode = "R006";
    private final RoleBasedAccessRepository roleBasedAccessRepository;

    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder,RoleBasedAccessRepository roleBasedAccessRepository ) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.roleBasedAccessRepository=roleBasedAccessRepository;
    }

    @Override
    public UserResponseDTO signup(UserRequestDTO userRequestDTO) {
        // logger.info("UserServiceImpl.signup - Signing up user: {}", userRequestDTO.getEmail());
        if (userRepository.existsById(userRequestDTO.getEmail())) {
            logger.error("UserServiceImpl.signup - User already exists with email: {}", userRequestDTO.getEmail());
            throw new IllegalStateException("User already exists with this email");
        }

        User user = new User(
                userRequestDTO.getEmail(),
                userRequestDTO.getPassword(),
                userRequestDTO.getFirstName(),
                userRequestDTO.getLastName()
        );
        Role role = roleBasedAccessRepository.findById(defaultRoleCode)
                .orElseGet(() -> roleBasedAccessRepository.save(
                        new Role(defaultRoleCode, "User", "Default user role")));
        user.setRoles(List.of(role));
        userRepository.save(user);
        logger.info("UserServiceImpl.signup - User signed up successfully: {}", userRequestDTO.getEmail());

        return new UserResponseDTO(user.getEmail(), user.getFirstName(), user.getLastName());
    }

    @Override
    public UserResponseDTO login(UserRequestDTO userRequestDTO){
        // logger.info("UserServiceImpl.login - Login attempt for user: {}", userRequestDTO.getEmail());
        User user = userRepository.findByEmail(
                userRequestDTO.getEmail()
        ).orElseThrow(() -> new IllegalStateException("User not found"));

        // Compare raw password with encoded password
        if (!passwordEncoder.matches(userRequestDTO.getPassword(), user.getPassword())) {
            logger.error("UserServiceImpl.login - Invalid password for user: {}", userRequestDTO.getEmail());
            throw new IllegalStateException("Invalid password");
        }

        // logger.info("UserServiceImpl.login - User logged in successfully: {}", userRequestDTO.getEmail());
        return new UserResponseDTO(user.getEmail(), user.getFirstName(), user.getLastName());
    }

    @Override
    public UserResponseDTO createUser(UserRequestDTO userRequestDTO) {
        User user = new User(
                userRequestDTO.getEmail(),
                userRequestDTO.getPassword(),
                userRequestDTO.getFirstName(),
                userRequestDTO.getLastName()
        );
        userRepository.save(user);
        return new UserResponseDTO(user.getEmail(), user.getFirstName(), user.getLastName());
    }

    @Override
    public UserResponseDTO getUserByEmail(String email) {
        // logger.info("UserServiceImpl.getUserByEmail - Fetching user: {}", email);
        return userRepository.findById(email)
                .map(user -> new UserResponseDTO(user.getEmail(), user.getFirstName(), user.getLastName()))
                .orElse(null);
    }

    @Override
    public List<UserResponseDTO> getAllUsers() {
        // logger.info("UserServiceImpl.getAllUsers - Fetching all users from DB");
        return userRepository.findAll().stream()
                .map(user -> new UserResponseDTO(user.getEmail(), user.getFirstName(), user.getLastName()))
                .collect(Collectors.toList());
    }

    @Override
    public void deleteUser(String email) {
        // logger.info("UserServiceImpl.deleteUser - Deleting user: {}", email);
        userRepository.deleteById(email);
    }
}
