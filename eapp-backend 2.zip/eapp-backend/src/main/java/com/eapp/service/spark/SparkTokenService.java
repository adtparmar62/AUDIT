package com.eapp.service.spark;



import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Service;

import com.eapp.dao.SparkTokenRepository;
import com.eapp.dto.requestDTO.SparkTokenRequestDTO;
import com.eapp.entity.SparkTokenEntity;
 
@Service

public class SparkTokenService {
    
    private static final Logger logger = LoggerFactory.getLogger(SparkTokenService.class);
 
    private final SparkTokenRepository repository;
 
    @Autowired
    public SparkTokenService(SparkTokenRepository repository) {

        this.repository = repository;

    }
 
    public String getValidToken() {
        logger.info("SparkTokenService.getValidToken - Fetching valid token from DB");

        SparkTokenEntity latest = repository.findTopByOrderByIdDesc()

            .orElseThrow(() -> new IllegalStateException("No token found in DB. Please insert a valid token."));
 
        if (latest.getExpiryTime() == null) {

            throw new IllegalStateException("Token expiry time is missing.");

        }

        if (latest.getExpiryTime().isBefore(LocalDateTime.now())) {

            throw new IllegalStateException("Stored token has expired. Please insert a new valid token.");

        }
 
        // ✅ Return raw JWT only

        return latest.getToken().trim();

    }
    
    
    // Method to update the spark token in DB
    public ResponseEntity<String> updateSparkToken(SparkTokenRequestDTO dto) {
        String sparkToken = dto.getSparkToken();

  
        if (sparkToken == null || !sparkToken.startsWith("Bearer ")) {
            return ResponseEntity.status(400).body("Invalid Token Format. Must start with 'Bearer '");
        }

        String trimmedToken = sparkToken.substring(7).trim();
        LocalDateTime newExpiry = LocalDateTime.now().plusHours(2);

 
        Optional<SparkTokenEntity> latestTokenOpt = repository.findTopByOrderByIdDesc();
        
        SparkTokenEntity entityToSave;

        if (latestTokenOpt.isPresent()) {
     
            entityToSave = latestTokenOpt.get();
            entityToSave.setToken(trimmedToken);
            entityToSave.setExpiryTime(newExpiry);
            logger.info("Updating existing token ID: {}", entityToSave.getId());
        } else {
          
            entityToSave = new SparkTokenEntity();
            entityToSave.setToken(trimmedToken);
            entityToSave.setExpiryTime(newExpiry);
            logger.info("No token found. Inserting new record.");
        }


        repository.save(entityToSave);

        return ResponseEntity.status(200).body("Token updated successfully until " + newExpiry);
    }

}

 