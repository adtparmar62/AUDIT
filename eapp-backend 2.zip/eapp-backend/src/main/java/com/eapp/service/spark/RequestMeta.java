
package com.eapp.service.spark;

import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@JsonInclude(JsonInclude.Include.ALWAYS)
@Entity
@Table(name = "t_metadata")
public class RequestMeta {

	@Id
	@Column(name = "version_id", length = 128, nullable = false)
	private String version_id;

	@Column(name = "call_purpose", length = 128, nullable = false)
	private String call_purpose;

	@Column(name = "source_system", length = 64, nullable = false)
	private String source_system;

	@Column(name = "correlation_id", length = 64)
	private String correlation_id;

	@Column(name = "requested_output", length = 128)
	private String requested_output;

	@Column(name = "service_category", length = 64)
	private String service_category;

	public RequestMeta() {
		// default no-arg constructor
	}

	// getters and setters

	public String getVersion_id() {
		return version_id;
	}

	public void setVersion_id(String version_id) {
		this.version_id = version_id;
	}

	public String getCall_purpose() {
		return call_purpose;
	}

	public void setCall_purpose(String call_purpose) {
		this.call_purpose = call_purpose;
	}

	public String getSource_system() {
		return source_system;
	}

	public void setSource_system(String source_system) {
		this.source_system = source_system;
	}

	public String getCorrelation_id() {
		return correlation_id;
	}

	public void setCorrelation_id(String correlation_id) {
		this.correlation_id = correlation_id;
	}

	public String getRequested_output() {
		return requested_output;
	}

	public void setRequested_output(String requested_output) {
		this.requested_output = requested_output;
	}

	public String getService_category() {
		return service_category;
	}

	public void setService_category(String service_category) {
		this.service_category = service_category;
	}
}
