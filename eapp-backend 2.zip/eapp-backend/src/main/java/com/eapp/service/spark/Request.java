package com.eapp.service.spark;

public class Request {

	public RequestData request_data = new RequestData();
	public RequestMeta request_meta = new RequestMeta();
	private String Response;

	public String getResponse() {
		return Response;
	}

	public void setResponse(String response) {
		Response = response;
	}

}
