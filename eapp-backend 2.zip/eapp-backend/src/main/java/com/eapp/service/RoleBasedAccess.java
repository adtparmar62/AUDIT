package com.eapp.service;

import java.util.List;

import com.eapp.entity.Policy;

public interface RoleBasedAccess {
	public List<Policy> isAccessableApplication(String email);
	
	public List<Policy> isAccessableProofing(String email);

}
