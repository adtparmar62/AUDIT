package com.eapp.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eapp.dao.TransactionDetailSequenceRepos;
import com.eapp.entity.TransactionDetailSequence;

@Service
public class TransactionDetailSequenceServiceImpl implements TransactionDetailSequenceService{
	
	private static final Logger logger = LoggerFactory.getLogger(TransactionDetailSequenceServiceImpl.class);

	@Autowired
	private TransactionDetailSequenceRepos transactionDetailSequenceRepos;

	public int incrementId() {
		logger.info("TransactionDetailSequenceServiceImpl.incrementId - Incrementing transaction sequence ID");
		TransactionDetailSequence transactionDetailSequence = transactionDetailSequenceRepos
				.save(new TransactionDetailSequence());
		return transactionDetailSequence.getId();
	}
}