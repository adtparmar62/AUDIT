package com.eapp.service;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eapp.dao.CaseDetailsRepos;
import com.eapp.dao.MVRtableRepos;
import com.eapp.dao.MibTableRepos;
import com.eapp.dto.reponseDTO.CaseResponseDTO;
import com.eapp.dto.reponseDTO.MibFullDetailsDTO;
import com.eapp.dto.reponseDTO.MvrFullDetailsDTO;
import com.eapp.entity.CaseDetails;

@Service
public class UnderwritingService {
    
    private static final Logger logger = LoggerFactory.getLogger(UnderwritingService.class);

    @Autowired
    private CaseDetailsRepos caseRepo;
    
    @Autowired
    private MibTableRepos mibTableRepos;
    
    @Autowired
    private MVRtableRepos mVRtableRepos;

    @Transactional
    public CaseResponseDTO saveFullCase(CaseDetails caseDetails) {
        logger.info("UnderwritingService.saveFullCase - Saving case details");
        syncRelationships(caseDetails);
        CaseDetails saved = caseRepo.save(caseDetails);
        return new CaseResponseDTO(saved);
    }

    public CaseResponseDTO getCase(Long id) {
        logger.info("UnderwritingService.getCase - Fetching case with ID: {}", id);
        CaseDetails caseObj = caseRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Case not found"));
        return new CaseResponseDTO(caseObj);
    }

    // GET ALL CASES
    public List<CaseResponseDTO> getAllCases() {
        return caseRepo.findAll()
                .stream()
                .map(CaseResponseDTO::new)
                .collect(Collectors.toList());
    }

    // UPDATE CASE
    @Transactional
    public CaseResponseDTO updateCase(Long id, CaseDetails updatedDetails) {
        logger.info("UnderwritingService.updateCase - Updating case with ID: {}", id);
        if (!caseRepo.existsById(id)) {
            logger.error("UnderwritingService.updateCase - Case not found with ID: {}", id);
            throw new RuntimeException("Cannot update. Case not found.");
        }
        updatedDetails.setCaseId(id); // Ensure the ID matches the path
        syncRelationships(updatedDetails);
        CaseDetails saved = caseRepo.save(updatedDetails);
        logger.info("UnderwritingService.updateCase - Case updated successfully");
        return new CaseResponseDTO(saved);
    }

    // DELETE CASE
    @Transactional
    public void deleteCase(Long id) {
        logger.info("UnderwritingService.deleteCase - Deleting case with ID: {}", id);
        if (!caseRepo.existsById(id)) {
            logger.error("UnderwritingService.deleteCase - Case not found with ID: {}", id);
            throw new RuntimeException("Cannot delete. Case not found.");
        }
        caseRepo.deleteById(id);
        logger.info("UnderwritingService.deleteCase - Case deleted successfully");
    }

    // Helper to keep logic DRY (Don't Repeat Yourself)
    private void syncRelationships(CaseDetails caseDetails) {
        if (caseDetails.getParties() != null) {
            caseDetails.getParties().forEach(p -> p.setCaseDetails(caseDetails));
        }
        if (caseDetails.getCoverages() != null) {
            caseDetails.getCoverages().forEach(c -> c.setCaseDetails(caseDetails));
        }
    }
    
    public MibFullDetailsDTO getSingleMibReport(String ssn) {
        List<MibFullDetailsDTO> reports = mibTableRepos.getDetailedMibBySsn(ssn);
        
        // Return only the first element if list is not empty, otherwise null or throw error
        return reports.isEmpty() ? null : reports.get(0);
    }

    public MvrFullDetailsDTO getSingleMvrReport(String dl) {
        List<MvrFullDetailsDTO> reports = mVRtableRepos.getDetailedMvrByDl(dl);
        
        return reports.isEmpty() ? null : reports.get(0);
    }
}