package com.eapp.service.spark;

import com.google.gson.JsonObject;

public class RequestData {

	private JsonObject inputs;

	public RequestData() {
		// TODO Auto-generated constructor stub
	}

	public JsonObject getInputs() {
		return inputs;
	}

	public void setInputs(JsonObject inputs) {
		this.inputs = inputs;
	}

}