package com.eapp.service;

import java.util.List;

import com.eapp.entity.UwPolicy;

public interface UwService {
	
	List<UwPolicy> validUw(String email);
}
