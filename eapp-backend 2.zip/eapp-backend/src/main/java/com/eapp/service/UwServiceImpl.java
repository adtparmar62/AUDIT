package com.eapp.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eapp.dao.UwPolicyRepository;
import com.eapp.entity.UwPolicy;

@Service
public class UwServiceImpl implements UwService{
	
	private static final Logger logger = LoggerFactory.getLogger(UwServiceImpl.class);
	
	@Autowired
	private UwPolicyRepository uwPolicyRepository;

	@Override
	public List<UwPolicy> validUw(String email) {
		// logger.info("UwServiceImpl.validUw - Fetching UW policies for email: {}", email);
		return uwPolicyRepository.findUwByRoleEmail(email);
	}


	
	

}
