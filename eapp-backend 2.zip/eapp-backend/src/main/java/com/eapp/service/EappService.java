package com.eapp.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.eapp.dao.UwPolicySummary;
import com.eapp.entity.QuoteDetails;
import com.eapp.entity.UwPolicy;

@Service
public interface EappService {

    QuoteDetails addQuote(QuoteDetails eapp);
	QuoteDetails create(QuoteDetails eapp);
	QuoteDetails update(QuoteDetails eapp);
	List<Map<String, Object>> getAll();
    List<UwPolicy> getAllUw();
    List<UwPolicySummary> getAllUwSummary();
	void deleteEappDetailsById(int id);
	QuoteDetails getEappDetailsById(int id);
	QuoteDetails getCaseDetailsByQuotoIdAndScreenNo(String quoationId, int screenNo);
    String generateQuoteId();
	void pullQuote();
	UwPolicy getUwByQuoteId(String id);
    String getAgentResponse(String quotationNo, String agent);
}
