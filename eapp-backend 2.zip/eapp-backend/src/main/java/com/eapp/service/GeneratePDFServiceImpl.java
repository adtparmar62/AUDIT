package com.eapp.service;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.eapp.dao.QuoteDetailsRepos;
import com.eapp.entity.QuoteDetails;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;

@Service
public class GeneratePDFServiceImpl implements GeneratePDFService {
	@Autowired
	private QuoteDetailsRepos quoteRepos;

	public List<QuoteDetails> getPDFData(String quoationId) {
		List<QuoteDetails> quoteList = new ArrayList<QuoteDetails>();
		for (int i = 1; i < 11; i++) {
			try {
				
				Optional<QuoteDetails> findDetailsWithLatestVersionNo = quoteRepos
						.findDetailsWithLatestVersionNo(quoationId, i);
				if (!findDetailsWithLatestVersionNo.isEmpty()) {
					quoteList.add(findDetailsWithLatestVersionNo.get());
			}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return quoteList;

	}


	public byte[] generateEappPDF(String quoationId) {
        
        // Safety check for input parameter
        if (quoationId == null || quoationId.trim().isEmpty()) {
            System.out.println("ERROR: Quotation ID is null or empty, cannot generate PDF.");
            return null;
        }

		List<QuoteDetails> quoteList = getPDFData(quoationId);
		
		System.out.println("Quote list is"+ quoteList);
		
		JRPdfExporter exporter = new JRPdfExporter();
		List<JasperPrint> jasperPrintList = new ArrayList<JasperPrint>();
		try {
			String jrxmlFileName = ResourceUtils.getFile("classpath:eAppPDF.jrxml").getAbsolutePath();
			Map<String, Object> parameters = new HashMap<String, Object>();
			
			// --- 1. Default values (Existing) ---
			parameters.put("customerName", "");
			parameters.put("insuredName", "");
			parameters.put("insuredDob", "");
			parameters.put("insuredGender", "");
			parameters.put("insuredNationality", "");
			parameters.put("insuredAddress", "");
			parameters.put("insuredMobile", "");
			parameters.put("insuredEmail", "");
			parameters.put("insuredId", "");
           
           	// --- 2. Default values (New Policy/Product Info) ---
           	parameters.put("prospectAgeGender", "N/A");
           	parameters.put("primaryAssuredName", "N/A");
           	parameters.put("primaryAssuredAgeGender", "N/A");
           	parameters.put("secondaryAssuredName", "NA");
           	parameters.put("secondaryAssuredAgeGender", "NA");
           	parameters.put("secondaryRiskClass", "NA");
           	parameters.put("riskClass", "N/A");
           	parameters.put("policyTerm", "N/A");
           	parameters.put("ppt", "N/A");
           	parameters.put("premiumAmount", "N/A");
           	parameters.put("premiumMode", "N/A");
           	parameters.put("proposalNo", "N/A");
           	parameters.put("productName", "N/A");
           	
			// Find the QuoteDetails object for Screen_No=1 (Personal Details)
			QuoteDetails screen1Details = null;
			if (quoteList != null && !quoteList.isEmpty()) {
				for (QuoteDetails detail : quoteList) {
					// Assuming getScreen_No() returns the integer Screen_No
					if (detail.getScreen_No() == 1) {	
						screen1Details = detail;
						break;	
					}
				}
			}

			// Logic to extract JSON Data from the correct Screen 1 details
			if (screen1Details != null) {
				String jsonData = screen1Details.getJSON_DATA();
				if (jsonData != null && !jsonData.isEmpty()) {
					ObjectMapper mapper = new ObjectMapper();
					JsonNode rootNode = mapper.readTree(jsonData);
					
					// 1. Existing Personal Details extraction
					String fName = rootNode.path("insuredFirstName").asText("");
					String sName = rootNode.path("insuredSurName").asText("");
					String fullName = fName + " " + sName;
					parameters.put("customerName", fullName);
					parameters.put("insuredName", fullName);
					
					String dobRaw = rootNode.path("insuredDateOfBirth").asText("");
					if(dobRaw.length() >= 10) {
						dobRaw = dobRaw.substring(0, 10);
					}
					parameters.put("insuredId", rootNode.path("insuredIdNumber").asText("-"));
					parameters.put("insuredDob", dobRaw);
					parameters.put("insuredGender", rootNode.path("insuredGender").asText(""));
					parameters.put("insuredNationality", rootNode.path("insuredNationality").asText(""));
					
					// 2. Address
					String villa = rootNode.path("regAddrVilla").asText("");
					String houseNo = rootNode.path("regAddrNum").asText("");
					String street = rootNode.path("regAddrStrNum").asText("");
					String zip = rootNode.path("regAddrZipCode").asText("");
					String district = rootNode.path("regAddrDist").asText("");
					
					StringBuilder addrBuilder = new StringBuilder();
					if(!villa.isEmpty()) addrBuilder.append(villa).append(", ");
					if(!houseNo.isEmpty()) addrBuilder.append(houseNo).append(" ");
					if(!street.isEmpty()) addrBuilder.append(street).append(", ");
					if(!district.isEmpty()) addrBuilder.append(district).append(" ");
					if(!zip.isEmpty()) addrBuilder.append(zip);
					
					parameters.put("insuredAddress", addrBuilder.toString().trim());
					
					// 3. Contact Info
					parameters.put("insuredMobile", rootNode.path("primaryNumber").asText(""));
					parameters.put("insuredEmail", rootNode.path("emailAddress").asText(""));

           			// 4. NEW: Policy/Product Info (Mapping JSON to PDF fields)
           			parameters.put("policyTerm", rootNode.path("policyTerm").asText("N/A"));
           			parameters.put("ppt", rootNode.path("premiumPaymentTerm").asText("N/A"));
           			parameters.put("premiumAmount", rootNode.path("premiumAmount").asText("N/A"));
           			parameters.put("premiumMode", rootNode.path("modeOfPayment").asText("N/A"));
           			parameters.put("proposalNo", rootNode.path("proposalNo").asText("N/A"));	
           			parameters.put("productName", rootNode.path("productName").asText("N/A"));
           			parameters.put("riskClass", rootNode.path("riskClass").asText("N/A"));
           			
           			// Complex fields (Prospect/Policyholder)
           			String prospectAge = rootNode.path("prospectAge").asText("27"); // Example default
           			String prospectGender = rootNode.path("prospectGender").asText("Female"); // Example default
           			parameters.put("prospectAgeGender", prospectAge + (prospectAge.isEmpty() ? "" : " Years") + (prospectGender.isEmpty() ? "" : ", " + prospectGender));

           			// Primary Life Assured
           			parameters.put("primaryAssuredName", rootNode.path("primaryLifeAssured").asText(fullName));

           			String primaryAssuredAge = rootNode.path("primaryAssuredAge").asText("27"); // Example default
           			String primaryAssuredGender = rootNode.path("primaryAssuredGender").asText("Female"); // Example default
           			parameters.put("primaryAssuredAgeGender", primaryAssuredAge + (primaryAssuredAge.isEmpty() ? "" : " Years") + (primaryAssuredGender.isEmpty() ? "" : ", " + primaryAssuredGender));

           			// Secondary Assured (based on PDF NA/NA)
           			parameters.put("secondaryAssuredName", rootNode.path("secondaryLifeAssured").asText("NA"));
           			parameters.put("secondaryAssuredAgeGender", rootNode.path("secondaryAssuredAgeGender").asText("NA"));
           			parameters.put("secondaryRiskClass", rootNode.path("secondaryRiskClass").asText("NA"));
				}
			}
           	
            // FIX: Override proposalNo with the input quoationId, regardless of JSON extraction success.
            // This is the specific change to ensure Quotation_id is used as the Application form number.
            parameters.put("proposalNo", quoationId);
            
           	// --- 3. Illustration Table Data Source (Repeating Data) ---
           	// Creating a data source based on the rows in the uploaded PDF	
           	List<Map<String, Object>> illustrationDataList = new ArrayList<>();
           	List<String> years = Arrays.asList("1", "2", "3", "4", "5", "6");
           	
           	for (String year : years) {
           	    Map<String, Object> row = new HashMap<>();
           	    row.put("policyYear", year);
           	    row.put("annualPremium", "9209.6");
           	    row.put("survivalBenefits", "0");
           	    row.put("otherBenefits", "0");
           	    row.put("maturityBenefit", "NA");
           	    row.put("deathBenefit", "2000000.0");
           	    row.put("minGuaranteedSV", "0");
           	    row.put("specialSV", "0");
           	    illustrationDataList.add(row);
           	}
           	
           	JRDataSource illustrationDataSource = new JRBeanCollectionDataSource(illustrationDataList);
           	parameters.put("ILLUSTRATION_DATA_SOURCE", illustrationDataSource);
           	// --- END NEW DATA SOURCE ---
           	

			JasperReport jasperReport = JasperCompileManager.compileReport(jrxmlFileName);
           
			// FIX: Replace JREmptyDataSource with a single-record JRBeanCollectionDataSource	
           	// for the main report. This is a common pattern to ensure the Detail band	
           	// is properly evaluated and embedded components are rendered.
           	List<String> singleReportRecord = Arrays.asList(""); // A list with one dummy element
           	JRDataSource mainDataSource = new JRBeanCollectionDataSource(singleReportRecord);
           
			// Use the new mainDataSource for filling the report.
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, mainDataSource);
			jasperPrintList.add(jasperPrint);

		} catch (Exception e) {
			System.out.println("Error Generating Report: An exception occurred. Please check the full stack trace below.");
			e.printStackTrace();
		}

		exporter.setExporterInput(SimpleExporterInput.getInstance(jasperPrintList));
		SimplePdfExporterConfiguration configuration = new SimplePdfExporterConfiguration();
		configuration.setCreatingBatchModeBookmarks(true);
		exporter.setConfiguration(configuration);

		try {
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(outputStream));
			exporter.exportReport();
			byte[] pdfByteArray = outputStream.toByteArray();
			System.out.println("Exporting pdf as byteararay");
			return pdfByteArray;
		} catch (Exception e) {
			System.out.println("Error Exporting pdf as byteararay");
			return null;

		}

	}

}