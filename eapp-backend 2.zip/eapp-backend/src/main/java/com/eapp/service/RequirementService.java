package com.eapp.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eapp.dao.UwPolicyRepository;
import com.eapp.dao.UwRequirementRepos;
import com.eapp.dto.reponseDTO.BatchRequirementsDTO;
import com.eapp.dto.reponseDTO.DocumentRequestDTO;
import com.eapp.entity.UwPolicy;
import com.eapp.entity.UwRequirement;

@Service
public class RequirementService {
    
    private static final Logger logger = LoggerFactory.getLogger(RequirementService.class);

    @Autowired
    private UwPolicyRepository uwPolicyRepository;

    @Autowired
    private UwRequirementRepos uwRequirementRepos;

    // STEP 1: INITIAL SAVE (Status -> Doc Pending)
    @Transactional
    public void saveBatchRequirements(BatchRequirementsDTO batchDto) {
        logger.info("RequirementService.saveBatchRequirements - Saving batch requirements for case: {}", batchDto.getTxnTypeId());
        String caseId = batchDto.getTxnTypeId();

        // Support both US and international formats
        DateTimeFormatter usFormatter = DateTimeFormatter.ofPattern("M/d/yyyy");
        DateTimeFormatter intlFormatter = DateTimeFormatter.ofPattern("d/M/yyyy");

        for (BatchRequirementsDTO.RequirementItem item : batchDto.getRows()) {
            // Find by both Application/Case ID and Name
            UwRequirement entity = uwRequirementRepos
                    .findTopByApplicationNumberAndRequirementName(caseId, item.getRequirementName())
                    .orElse(new UwRequirement());

            entity.setApplicationNumber(caseId);
            entity.setRequirementName(item.getRequirementName());
            entity.setRequirementType(item.getRequirementType());
            entity.setRequestedBy(item.getRequestedBy());

            // Fetch the correct UwPolicy by policyId and update stateId
            UwPolicy uwPolicy = uwPolicyRepository.findByPolicyId(caseId);
            if (uwPolicy != null && uwPolicy.getStateId() != 5) {
                logger.info("RequirementService.saveBatchRequirements - Updating UW policy state to 4 for policy: {}", caseId);
                uwPolicy.setStateId(4);
                uwPolicyRepository.save(uwPolicy);
            } else {
                logger.info("RequirementService.saveBatchRequirements - UW policy not updated, either null or already in state 5");
            }

            // Status changes to "Pending" unless already "Doc Received"
            if (!"Doc Received".equals(entity.getStatus())) {
                entity.setStatus("Pending");
            }

            // Defensive date parsing
            if (item.getRequirementRequestDate() != null && !item.getRequirementRequestDate().isEmpty()) {
                String dateStr = item.getRequirementRequestDate();
                try {
                    entity.setRequestDate(LocalDate.parse(dateStr, usFormatter));
                } catch (DateTimeParseException e1) {
                    try {
                        entity.setRequestDate(LocalDate.parse(dateStr, intlFormatter));
                    } catch (DateTimeParseException e2) {
                        logger.error("RequirementService.saveBatchRequirements - Invalid date format: {}", dateStr);
                        throw new IllegalArgumentException("Invalid date format: " + dateStr);
                    }
                }
            }

            entity.setAttachment(item.getAttachment()); // Initial empty string or provided value
            uwRequirementRepos.save(entity);
        }
        logger.info("RequirementService.saveBatchRequirements - Batch requirements saved successfully");
    }

    // STEP 2: UPLOAD (Finds record and attaches Base64)
    @Transactional
    public String uploadRequirementDocument(DocumentRequestDTO.Payload payload) {
        logger.info("RequirementService.uploadRequirementDocument - Uploading document for application: {}, requirement: {}", payload.getApplicationNumber(), payload.getRequirementName());
        // Find the record created in Step 1
        UwRequirement requirement = uwRequirementRepos
                .findTopByApplicationNumberAndRequirementName(payload.getApplicationNumber(),
                        payload.getRequirementName())
                .orElseThrow(() -> new RuntimeException("Requirement not found. Please save the batch first."));

        UwPolicy uwPolicy = uwPolicyRepository.findByPolicyId(payload.getApplicationNumber());
        if (uwPolicy != null) {
            logger.info("RequirementService.uploadRequirementDocument - Updating UW policy state to 5 for policy: {}", payload.getApplicationNumber());
            uwPolicy.setStateId(5);
            uwPolicyRepository.save(uwPolicy);
        } else {
            logger.warn("RequirementService.uploadRequirementDocument - UW policy not found for application: {}", payload.getApplicationNumber());
        }

        requirement.setFileName(payload.getFileName());
        requirement.setBase64Content(payload.getBase64string());
        // requirement.setAttachment(payload.getBase64string()); // If you want to sync with attachment column

        // Status changes to "Doc Received"
        requirement.setStatus("Doc Received");
        requirement.setDateReceived(LocalDate.now());
        // requirement.setReceivedFrom("Underwriter Portal");

        uwRequirementRepos.save(requirement);
        logger.info("RequirementService.uploadRequirementDocument - Document uploaded successfully: {}", payload.getFileName());
        return "Document " + payload.getFileName() + " uploaded and status updated to Doc Received.";
    }

    @Transactional(readOnly = true)
    public List<UwRequirement> getAll() {
        return uwRequirementRepos.findAll();
    }

    @Transactional(readOnly = true)
    public UwRequirement getById(Long id) {
        return uwRequirementRepos.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Requirement not found for id=" + id));
    }

    @Transactional(readOnly = true)
    public List<UwRequirement> getByApplicationNumber(String applicationNumber) {
        logger.info("RequirementService.getByApplicationNumber - Fetching requirements for application: {}", applicationNumber);
        return uwRequirementRepos.findByApplicationNumber(applicationNumber);
    }

    // Optional status update method
    // @Transactional
    // public void updateRequirementStatus(String appNo, String status) {
    //     UwRequirement requirement = uwRequirementRepos.findByApplicationNumber(appNo)
    //             .orElseThrow(() -> new RuntimeException("Requirement not found for app: " + appNo));
    //     requirement.setStatus(status);
    //     uwRequirementRepos.save(requirement);
    // }
}
