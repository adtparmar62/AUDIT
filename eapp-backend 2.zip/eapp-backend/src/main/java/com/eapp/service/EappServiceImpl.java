package com.eapp.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.eapp.dao.AgentRecordResponseRepository;
import com.eapp.dao.PolicyRepository;
import com.eapp.dao.QuoteDetailsRepos;
import com.eapp.dao.UwPolicySummary;
import com.eapp.dao.UwPolicyRepository;
import com.eapp.entity.Policy;
import com.eapp.entity.QuoteDetails;
import com.eapp.entity.UwPolicy;
import com.eapp.entity.rule.AgentRecordResponse;

import jakarta.transaction.Transactional;

@Service
public class EappServiceImpl implements EappService {
    
    private static final Logger logger = LoggerFactory.getLogger(EappServiceImpl.class);
    @Autowired
    private QuoteDetailsRepos eappRepos;

    @Autowired
    private UwPolicyRepository uwPolicyRepository;

    @Autowired
    private TransactionDetailSequenceServiceImpl transactionDetailSequenceService;

    @Autowired
    private PolicyRepository policyRepository;

    @Autowired
    private AgentRecordResponseRepository agentRecordResponseRepository;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public QuoteDetails addQuote(QuoteDetails eapp){
        // logger.info("EappServiceImpl.addQuote - Adding quote for quotation_id: {}", eapp.getQuotation_id());
        return eappRepos.save(eapp);
    }

    @Override
    public QuoteDetails create(QuoteDetails eapp) {
        // logger.info("EappServiceImpl.create - Creating quote for quotation_id: {}, screen_no: {}", eapp.getQuotation_id(), eapp.getScreen_No());
        try {
            Policy policy = policyRepository.findById(eapp.getQuotation_id() )
                    .orElseThrow(() -> new RuntimeException("Policy not found"));
            Optional<QuoteDetails> detailsNewVersionNo = eappRepos.findDetailsWithLatestVersionNo(eapp.getQuotation_id(),eapp.getScreen_No());
            eapp.setUPDATED_BY("Dummy");
            eapp.setUPDATED_TIME(new Date());
            QuoteDetails savedEapp = null;
            if(detailsNewVersionNo.isEmpty()) {
                // logger.info("EappServiceImpl.create - No existing version found, creating new version");
                eapp.setCREATED_BY("dummy");
                eapp.setCREATION_TIME(new Date());
                savedEapp=eappRepos.save(eapp);
            } else {
                // logger.info("EappServiceImpl.create - Existing version found, incrementing version number");
                eapp.setVERSION_NO(detailsNewVersionNo.get().getVERSION_NO()+1);
                eapp.setCREATED_BY(detailsNewVersionNo.get().getCREATED_BY());
                eapp.setCREATION_TIME(detailsNewVersionNo.get().getCREATION_TIME());
                detailsNewVersionNo.get().setEFFECTIVE_END_DATE(new Date());
                eappRepos.save(detailsNewVersionNo.get());
                savedEapp=eappRepos.save(eapp);
            }
            if(eapp.getScreen_No() == 1) {
                // logger.info("EappServiceImpl.create - Updating policy holder name for screen 1");
                policy.setHolderName(eapp.getProspectName());
            }
            if(eapp.getScreen_No() == 2) {
                // logger.info("EappServiceImpl.create - Updating policy details for screen 2");
                policy.setSa( Double.parseDouble(eapp.getSumAssured()));
                policy.setPeriodPrem(Double.parseDouble(eapp.getPremiumAmount()));
                policy.setNormalPrem(Double.parseDouble(eapp.getInstallmentPremium()));
                policy.setProductName(eapp.getProductName());
            }
            policyRepository.save(policy);
            // logger.info("EappServiceImpl.create - Quote created successfully");
            return savedEapp;
        }catch(Exception e) {
            logger.error("EappServiceImpl.create - Error creating quote: {}", e.getMessage(), e);
            e.printStackTrace();
        }
        // logger.warn("EappServiceImpl.create - Returning null due to error");
        return null;
    }

    @Override
    public QuoteDetails update(QuoteDetails eapp) {
        return eappRepos.save(eapp);
    }

    @Override
    public List<Map<String, Object>> getAll() {
        String sql = "SELECT t.Quotation_id AS quotation_id, t.Screen_No AS screen_No, t.JSON_DATA AS json_DATA " +
                     "FROM t_quotation_save t " +
                     "INNER JOIN (" +
                     "  SELECT Quotation_id, Screen_No, MAX(VERSION_NO) AS max_version " +
                     "  FROM t_quotation_save " +
                     "  WHERE Screen_No IN (1, 2) " +
                     "  GROUP BY Quotation_id, Screen_No" +
                     ") latest ON t.Quotation_id = latest.Quotation_id " +
                     "        AND t.Screen_No = latest.Screen_No " +
                     "        AND t.VERSION_NO = latest.max_version";
        return jdbcTemplate.queryForList(sql);
    }

    @Override
    public List<UwPolicy> getAllUw() {
        return uwPolicyRepository.findAll();
    }

    @Override
    public List<UwPolicySummary> getAllUwSummary() {
        return uwPolicyRepository.findAllSummary();
    }
    @Override
    public QuoteDetails getEappDetailsById(int id) {
        return eappRepos.findById(id).get();
    }

    @Override
    public void deleteEappDetailsById(int id) {
        eappRepos.deleteById(id);
    }

    @Override
    public QuoteDetails getCaseDetailsByQuotoIdAndScreenNo(String quoationId, int screenNo) {
        // logger.info("EappServiceImpl.getCaseDetailsByQuotoIdAndScreenNo - Fetching details for quotation_id: {}, screen_no: {}", quoationId, screenNo);
        try {
            Optional<QuoteDetails> detailsNewVersionNo = eappRepos.findDetailsWithLatestVersionNo(quoationId,screenNo);
            if(detailsNewVersionNo.isEmpty()) {
                // logger.warn("EappServiceImpl.getCaseDetailsByQuotoIdAndScreenNo - No details found, returning null");
                return null;
            }
            // logger.info("EappServiceImpl.getCaseDetailsByQuotoIdAndScreenNo - Details found successfully");
            return detailsNewVersionNo.get();
        }catch(Exception e) {
            logger.error("EappServiceImpl.getCaseDetailsByQuotoIdAndScreenNo - Error: {}", e.getMessage(), e);
            e.printStackTrace();
        }
        // logger.warn("EappServiceImpl.getCaseDetailsByQuotoIdAndScreenNo - Returning null due to error");
        return null;
    }

    @Override
    public String generateQuoteId(){
        // logger.info("EappServiceImpl.generateQuoteId - Generating new quote ID");
        int incrementId = transactionDetailSequenceService.incrementId();
        String policyId = String.format("Q%09d", incrementId);
        policyRepository.save(new Policy(policyId));
        logger.info("EappServiceImpl.generateQuoteId - Generated quote ID: {}", policyId);
        return policyId;
    }
    
    @Transactional
	@Override
	public void pullQuote() {
		eappRepos.bulkPullQuotes();
	}
    @Override
    public UwPolicy getUwByQuoteId(String id) {
        return uwPolicyRepository.findByPolicyId(id);
    }

    @Override
    public String getAgentResponse(String quotationNo, String agent) {
        // logger.info("EappServiceImpl.getAgentResponse - Fetching agent response for quotation_no: {}, agent: {}", quotationNo, agent);
        Optional<AgentRecordResponse> record = agentRecordResponseRepository.findByQuotationNoAndAgent(quotationNo, agent);

        return record.map(AgentRecordResponse::getResponse).orElse(null);
    }

}