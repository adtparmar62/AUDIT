package com.eapp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "MASTER_LOOKUP")
public class MasterLookup {

	@Id
	@Column(name = "LOOKUP_CODE")
	private String lookupCode; // Unique identifier (e.g., 'GND_MALE')

	@Column(name = "LOOKUP_NAME")
	private String lookupName; // Categorization (e.g., 'GENDER')

	@Column(name = "LOOKUP_VALUE")
	private String lookupValue; // Display text (e.g., 'Male')

	// Default Constructor
	public MasterLookup() {
	}

	// Parameterized Constructor
	public MasterLookup(String lookupCode, String lookupName, String lookupValue) {
		this.lookupCode = lookupCode;
		this.lookupName = lookupName;
		this.lookupValue = lookupValue;
	}

	// Getters and Setters
	public String getLookupCode() {
		return lookupCode;
	}

	public void setLookupCode(String lookupCode) {
		this.lookupCode = lookupCode;
	}

	public String getLookupName() {
		return lookupName;
	}

	public void setLookupName(String lookupName) {
		this.lookupName = lookupName;
	}

	public String getLookupValue() {
		return lookupValue;
	}

	public void setLookupValue(String lookupValue) {
		this.lookupValue = lookupValue;
	}
}
