package com.eapp.entity;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "UW_PARTY")
public class Party {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PARTY_ID")
    private Long partyId;

    @Column(name = "FULL_NAME")
    private String fullName;

    @Column(name = "DOB")
    private LocalDate dateOfBirth;

    @Column(name = "ADDRESS_ID")
    private Long addressId; 

    @Column(name = "HEIGHT")
    private Double height;

    @Column(name = "WEIGHT")
    private Double weight;

    @Column(name = "TOBACO")
    private Boolean isTobaccoUser; 

    @Column(name = "GENDER")
    private String gender;

    @Column(name = "SSN")
    private String ssn;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CASE_ID", nullable = false) 
    @JsonIgnore // Prevents Infinite Loop during JSON serialization
    private CaseDetails caseDetails;

    public Party() {}

    // Getters and Setters
    public Long getPartyId() { return partyId; }
    public void setPartyId(Long partyId) { this.partyId = partyId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }

    public Long getAddressId() { return addressId; }
    public void setAddressId(Long addressId) { this.addressId = addressId; }

    public Double getHeight() { return height; }
    public void setHeight(Double height) { this.height = height; }

    public Double getWeight() { return weight; }
    public void setWeight(Double weight) { this.weight = weight; }

    public Boolean getIsTobaccoUser() { return isTobaccoUser; }
    public void setIsTobaccoUser(Boolean isTobaccoUser) { this.isTobaccoUser = isTobaccoUser; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getSsn() { return ssn; }
    public void setSsn(String ssn) { this.ssn = ssn; }

    public CaseDetails getCaseDetails() { return caseDetails; }
    public void setCaseDetails(CaseDetails caseDetails) { this.caseDetails = caseDetails; }
}