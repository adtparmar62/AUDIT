
package com.eapp.entity;

import java.io.Serializable;
import java.util.Objects;

public class CoverageFieldsId implements Serializable {
    private Long coverageId;
    private String fieldName;

    public CoverageFieldsId() {}

    public CoverageFieldsId(Long coverageId, String fieldName) {
        this.coverageId = coverageId;
        this.fieldName = fieldName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CoverageFieldsId)) return false;
        CoverageFieldsId that = (CoverageFieldsId) o;
        return Objects.equals(coverageId, that.coverageId) &&
               Objects.equals(fieldName, that.fieldName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(coverageId, fieldName);
    }
}

