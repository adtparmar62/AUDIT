package com.eapp.entity.rule;

import java.sql.Timestamp;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "agent_record_response")
public class AgentRecordResponse {

    @Id
    @Column(name = "quotation_no", length = 50)
    private String quotationNo;

    @Column(name = "agent", length = 255)
    private String agent;

    @Column(name = "input", columnDefinition = "json")
    private String input;

    @Column(name = "response", columnDefinition = "json")
    private String response;

    @Column(name = "created_at", insertable = false, updatable = false)
    private Timestamp createdAt;

    @Column(name = "prompt_input", columnDefinition = "LONGTEXT")
    private String promptInput;

    public String getQuotationNo() { return quotationNo; }
    public void setQuotationNo(String quotationNo) { this.quotationNo = quotationNo; }

    public String getAgent() { return agent; }
    public void setAgent(String agent) { this.agent = agent; }

    public String getInput() { return input; }
    public void setInput(String input) { this.input = input; }

    public String getResponse() { return response; }
    public void setResponse(String response) { this.response = response; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public String getPromptInput() { return promptInput; }
    public void setPromptInput(String promptInput) { this.promptInput = promptInput; }
}
