package com.eapp.entity;

public class CalculationRequest {
	private double tp;
	private double em;
	private double permile;
	private int occupationClass;
	private String riskClass;

	// Standard Getters and Setters
	public double getTp() {
		return tp;
	}

	public void setTp(double tp) {
		this.tp = tp;
	}

	// ... (other getters/setters for em, permile, occupationClass, riskClass)
	public double getEm() {
		return em;
	}

	public void setEm(double em) {
		this.em = em;
	}

	public double getPermile() {
		return permile;
	}

	public void setPermile(double permile) {
		this.permile = permile;
	}

	public int getOccupationClass() {
		return occupationClass;
	}

	public void setOccupationClass(int occupationClass) {
		this.occupationClass = occupationClass;
	}

	public String getRiskClass() {
		return riskClass;
	}

	public void setRiskClass(String riskClass) {
		this.riskClass = riskClass;
	}
}