package com.eapp.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "UD_COVERAGE_FIELDS")
@IdClass(CoverageFieldsId.class)
public class CoverageFields {

	@Id
	@Column(name = "COVERAGE_ID", nullable = false)
	private Long coverageId;

	@Id
	@Column(name = "FIELD_NAME", nullable = false)
	private String fieldName;

	@Column(name = "FIELD_TYPE")
	private String fieldType; // e.g., "STRING", "DATE", "NUMBER"

	@Column(name = "T_STRING")
	private String tString;

	@Column(name = "T_DATE")
	private LocalDate tDate;

	@Column(name = "T_NUMBER")
	private BigDecimal tNumber;

	@Column(name = "T_FLOAT")
	private Double tFloat;

	@Column(name = "T_INT")
	private Integer tInt;

	// Default Constructor
	public CoverageFields() {
	}

	// Getters and Setters

	public Long getCoverageId() {
		return coverageId;
	}

	public void setCoverageId(Long coverageId) {
		this.coverageId = coverageId;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public String getTString() {
		return tString;
	}

	public void setTString(String tString) {
		this.tString = tString;
	}

	public LocalDate getTDate() {
		return tDate;
	}

	public void setTDate(LocalDate tDate) {
		this.tDate = tDate;
	}

	public BigDecimal getTNumber() {
		return tNumber;
	}

	public void setTNumber(BigDecimal tNumber) {
		this.tNumber = tNumber;
	}

	public Double getTFloat() {
		return tFloat;
	}

	public void setTFloat(Double tFloat) {
		this.tFloat = tFloat;
	}

	public Integer getTInt() {
		return tInt;
	}

	public void setTInt(Integer tInt) {
		this.tInt = tInt;
	}
}
