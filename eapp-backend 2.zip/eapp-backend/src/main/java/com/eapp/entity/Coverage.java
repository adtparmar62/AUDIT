package com.eapp.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "UD_COVERAGE")
public class Coverage {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "COVERAGE_ID")
	private Long coverageId;

	// This is the Foreign Key mapping
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CASE_ID", nullable = false)
	@JsonIgnore
	private CaseDetails caseDetails;

	@Column(name = "Rider_Type")
	private String riderType;

	@Column(name = "Coverage_Amount")
	private BigDecimal coverageAmount; 

	@Column(name = "Start_date")
	private LocalDate startDate;

	@Column(name = "End_Date")
	private LocalDate endDate;

	@Column(name = "RIDER_NAME")
	private String riderName;

	// Default Constructor
	public Coverage() {
	}

	// Getters and Setters
	public Long getCoverageId() {
		return coverageId;
	}

	public void setCoverageId(Long coverageId) {
		this.coverageId = coverageId;
	}

	public CaseDetails getCaseDetails() {
		return caseDetails;
	}

	public void setCaseDetails(CaseDetails caseDetails) {
		this.caseDetails = caseDetails;
	}

	public String getRiderType() {
		return riderType;
	}

	public void setRiderType(String riderType) {
		this.riderType = riderType;
	}

	public BigDecimal getCoverageAmount() {
		return coverageAmount;
	}

	public void setCoverageAmount(BigDecimal coverageAmount) {
		this.coverageAmount = coverageAmount;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getRiderName() {
		return riderName;
	}

	public void setRiderName(String riderName) {
		this.riderName = riderName;
	}
}
