package com.eapp.entity.rule;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "T_RULE_DEF")
public class RuleDef {

    @Id
    @Column(name = "V_RULE_CODE")
    private String ruleCode;

    @Column(name = "RULE_DEFINITION", columnDefinition = "TEXT")
    private String ruleDefinition;

    public RuleDef() {}

    public RuleDef(String ruleCode, String ruleDefinition) {
        this.ruleCode = ruleCode;
        this.ruleDefinition = ruleDefinition;
    }

    public String getRuleCode() { return ruleCode; }
    public void setRuleCode(String ruleCode) { this.ruleCode = ruleCode; }

    public String getRuleDefinition() { return ruleDefinition; }
    public void setRuleDefinition(String ruleDefinition) { this.ruleDefinition = ruleDefinition; }
}
