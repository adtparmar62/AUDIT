package com.eapp.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "t_uw_policy")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UwPolicy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "uw_id")
    private Long uwid;

    @Column(name = "policy_id")
    private String policyId;

    @Column(name = "underwriter_id")
    private String underwriterId;

    @Column(name = "uw_detail_id")
    private Long uwDetailId;
    
    @Column(name = "assign_role", length = 100)
    private String assignRole;
    
    @Column(name = "SA")
    private Double sa;

    @Column(name = "period_prem")
    private Double periodPrem;

    @Column(name = "normal_prem")
    private Double normalPrem;

    @Column(name = "uw_status")
    private int stateId;

    @Column(name = "product_name")
    private String product;
    
    @Lob 
    @Column(columnDefinition = "LONGTEXT")
    private String content;
    
    @Lob 
    @Column(name= "output_data", columnDefinition = "LONGTEXT")
    private String outputData;

	public Long getUwid() {
		return uwid;
	}

	public void setUwid(Long uwid) {
		this.uwid = uwid;
	}

	public String getPolicyId() {
		return policyId;
	}

	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}

	public String getUnderwriterId() {
		return underwriterId;
	}

	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}

	public Long getUwDetailId() {
		return uwDetailId;
	}

	public void setUwDetailId(Long uwDetailId) {
		this.uwDetailId = uwDetailId;
	}

	public String getAssignRole() {
		return assignRole;
	}

	public void setAssignRole(String assignRole) {
		this.assignRole = assignRole;
	}

	public Double getSa() {
		return sa;
	}

	public void setSa(Double sa) {
		this.sa = sa;
	}

	public Double getPeriodPrem() {
		return periodPrem;
	}

	public void setPeriodPrem(Double periodPrem) {
		this.periodPrem = periodPrem;
	}

	public Double getNormalPrem() {
		return normalPrem;
	}

	public void setNormalPrem(Double normalPrem) {
		this.normalPrem = normalPrem;
	}

	public int getStateId() {
		return stateId;
	}

	public void setStateId(int stateId) {
		this.stateId = stateId;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getOutputData() {
		return outputData;
	}

	public void setOutputData(String outputData) {
		this.outputData = outputData;
	}
}