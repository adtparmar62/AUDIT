package com.eapp.entity;

import java.time.LocalDateTime;


import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.eapp.service.UserServiceImpl;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Entity
@Table(schema = "coherentdemo_uidbnew", name = "t_policy")
@Data
//@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Policy {

     public Policy() {
    
     }
    public Policy(String policyId) {
        this.policyId = policyId;
    }

    @Id
    // @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "policy_id")
    private String policyId;

    @Column(name = "SA")
    private double sa;

    @Column(name = "period_prem")
    private double periodPrem;

    @Column(name = "normal_prem")
    private double normalPrem;

    @Column(name = "state_id")
    private int stateId = 1;

    @CreationTimestamp
    @Column(name = "insert_time", updatable = false)
    private LocalDateTime insertTime;

    @UpdateTimestamp
    @Column(name = "update_time")
    private LocalDateTime updateTime;

    @Column(name = "assign_role", length = 100)
    private String assignRole = UserServiceImpl.defaultRoleCode;
    @Column(name = "holder_name")
    private String holderName;
    @Column(name = "product_name")
    private String productName;

    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public double getSa() {
        return sa;
    }

    public void setSa(double sa) {
        this.sa = sa;
    }

    public double getPeriodPrem() {
        return periodPrem;
    }

    public void setPeriodPrem(double periodPrem) {
        this.periodPrem = periodPrem;
    }

    public double getNormalPrem() {
        return normalPrem;
    }

    public void setNormalPrem(double normalPrem) {
        this.normalPrem = normalPrem;
    }

    public int getStateId() {
        return stateId;
    }

    public void setStateId(int stateId) {
        this.stateId = stateId;
    }

    public LocalDateTime getInsertTime() {
        return insertTime;
    }

    public void setInsertTime(LocalDateTime insertTime) {
        this.insertTime = insertTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public String getAssignRole() {
        return assignRole;
    }

    public void setAssignRole(String assignRole) {
        this.assignRole = assignRole;
    }

    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

}