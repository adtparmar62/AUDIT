package com.eapp.entity.rule;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "T_WORK")
public class Work {

    @Id
    @Column(name = "WORK_CODE")
    private String workCode;

    @Column(name = "WORK_TYPE")
    private String workType;

    @Column(name = "WORK_DESC")
    private String workDesc;

    // Direct mapping to rules
    @ManyToMany
    @JoinTable(
            name = "T_WORKWISE_RULE",
            joinColumns = @JoinColumn(name = "WORK_CODE"),
            inverseJoinColumns = @JoinColumn(name = "RULE_CODE")
    )
    private List<Rule> rules;

    public Work() {}

    public Work(String workCode, String workType, String workDesc) {
        this.workCode = workCode;
        this.workType = workType;
        this.workDesc = workDesc;
    }

    public String getWorkCode() { return workCode; }
    public void setWorkCode(String workCode) { this.workCode = workCode; }

    public String getWorkType() { return workType; }
    public void setWorkType(String workType) { this.workType = workType; }

    public String getWorkDesc() { return workDesc; }
    public void setWorkDesc(String workDesc) { this.workDesc = workDesc; }

    public List<Rule> getRules() { return rules; }
    public void setRules(List<Rule> rules) { this.rules = rules; }
}
