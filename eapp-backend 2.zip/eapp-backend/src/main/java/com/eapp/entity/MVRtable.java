package com.eapp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "MVRtable")
public class MVRtable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "DL", nullable = false)
    private String dl; // Driver's License Number

    @Column(name = "penaltyCode", nullable = false)
    private String penaltyCode; // Violation code (e.g., 'SPD' for Speeding)

    // Default Constructor
    public MVRtable() {}

    // Parameterized Constructor
    public MVRtable(String dl, String penaltyCode) {
        this.dl = dl;
        this.penaltyCode = penaltyCode;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDl() { return dl; }
    public void setDl(String dl) { this.dl = dl; }

    public String getPenaltyCode() { return penaltyCode; }
    public void setPenaltyCode(String penaltyCode) { this.penaltyCode = penaltyCode; }
}