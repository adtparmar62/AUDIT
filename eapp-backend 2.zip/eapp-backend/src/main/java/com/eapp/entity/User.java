package com.eapp.entity;

import java.util.List;

import com.eapp.entity.role.Role;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "user")
public class User {
    @Id
    @Column(name = "email")   // maps to column 'email'
    private String email;

    @Column(name = "password") // maps to column 'password'
    private String password;

    @Column(name = "firstname") // adjust to your actual DB column name
    private String firstName;

    @Column(name = "lastname")  // adjust to your actual DB column name
    private String lastName;
    
    @ManyToMany
    @JoinTable(
            name = "T_ROLE_USER",
            joinColumns = @JoinColumn(name = "EMAIL"),
            inverseJoinColumns = @JoinColumn(name = "ROLE_CODE")
    )
    private List<Role> roles;

    public User(String email, String password, String firstName, String lastName) {
        this.email = email;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public User() {

    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public List<Role> getRoles() { return roles; }
    public void setRoles(List<Role> roles) { this.roles = roles; }
}
