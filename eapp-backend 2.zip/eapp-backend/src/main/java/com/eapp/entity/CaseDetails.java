package com.eapp.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "UW_CaseDetails")
public class CaseDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CASE_ID")
    private Long caseId;

    @Column(name = "QUOTATION_ID", unique = true, nullable = false)
    private String quotationId;

    @Column(name = "SEARCH_KEY")
    private String searchKey;

    @Column(name = "Quotation_Date")
    private LocalDate quotationDate;

    @Column(name = "Application_number")
    private String applicationNumber;

    @Column(name = "MARKET_NAME")
    private String marketName;

    @Column(name = "CASE_STATUS")
    private String caseStatus;

    @Column(name = "Assigned_to")
    private String assignedTo;

    @Column(name = "Issue_date")
    private LocalDate issueDate;

    // Relationship to Party
    // CascadeType.ALL ensures that saving CaseDetails also saves the Parties
   // @JsonIgnore
    @OneToMany(mappedBy = "caseDetails", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Party> parties = new ArrayList<>();
    
    @OneToMany(mappedBy = "caseDetails", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Coverage> coverages = new ArrayList<>();

    // 2. Add this helper/setter to handle the bidirectional link
    public void setCoverages(List<Coverage> coverages) {
        this.coverages = coverages;
        if (coverages != null) {
            coverages.forEach(c -> c.setCaseDetails(this));
        }
    }

    // 3. Add the getter
    public List<Coverage> getCoverages() { return coverages; }

    public CaseDetails() {}

    // Helper method to sync bidirectional relationship
    public void setParties(List<Party> parties) {
        this.parties = parties;
        if (parties != null) {
            parties.forEach(p -> p.setCaseDetails(this));
        }
    }

    public List<Party> getParties() { return parties; }

    // Standard Getters and Setters
    public Long getCaseId() { return caseId; }
    public void setCaseId(Long caseId) { this.caseId = caseId; }

    public String getQuotationId() { return quotationId; }
    public void setQuotationId(String quotationId) { this.quotationId = quotationId; }

    public String getSearchKey() { return searchKey; }
    public void setSearchKey(String searchKey) { this.searchKey = searchKey; }

    public LocalDate getQuotationDate() { return quotationDate; }
    public void setQuotationDate(LocalDate quotationDate) { this.quotationDate = quotationDate; }

    public String getApplicationNumber() { return applicationNumber; }
    public void setApplicationNumber(String applicationNumber) { this.applicationNumber = applicationNumber; }

    public String getMarketName() { return marketName; }
    public void setMarketName(String marketName) { this.marketName = marketName; }

    public String getCaseStatus() { return caseStatus; }
    public void setCaseStatus(String caseStatus) { this.caseStatus = caseStatus; }

    public String getAssignedTo() { return assignedTo; }
    public void setAssignedTo(String assignedTo) { this.assignedTo = assignedTo; }

    public LocalDate getIssueDate() { return issueDate; }
    public void setIssueDate(LocalDate issueDate) { this.issueDate = issueDate; }
}