package com.eapp.entity;

import java.util.Date;

import com.fasterxml.jackson.core.JsonProcessingException;
// REQUIRED IMPORTS FOR JSON PARSING
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity(name = "t_quotation_save")
@Table(name = "t_quotation_save")
public class QuoteDetails {
	
	// ObjectMapper is thread-safe and can be static
	private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Quotation_Save_id;

	private String Quotation_id;
	
	private int Screen_No;
	private int VERSION_NO = 1;

    @Column(columnDefinition = "LONGTEXT")
	private String JSON_DATA; // The field containing all the PDF data

	private Date CREATION_TIME;
	private String CREATED_BY;
	private Date UPDATED_TIME;
	private String UPDATED_BY;
	private Date EFFECTIVE_END_DATE;
	
	public QuoteDetails() {
	}
	
	public QuoteDetails(String quotation_id, int screen_No, String jSON_DATA) {
		super();
		Quotation_id = quotation_id;
		Screen_No = screen_No;
		JSON_DATA = jSON_DATA;
	}
	
	public QuoteDetails(int quotation_Save_id, String quotation_id, int screen_No, int vERSION_NO, String jSON_DATA,
			Date cREATION_TIME, String cREATED_BY, Date uPDATED_TIME, String uPDATED_BY, Date eFFECTIVE_END_DATE) {
		super();
		Quotation_Save_id = quotation_Save_id;
		Quotation_id = quotation_id;
		Screen_No = screen_No;
		VERSION_NO = vERSION_NO;
		JSON_DATA = jSON_DATA;
		CREATION_TIME = cREATION_TIME;
		CREATED_BY = cREATED_BY;
		UPDATED_TIME = uPDATED_TIME;
		UPDATED_BY = uPDATED_BY;
		EFFECTIVE_END_DATE = eFFECTIVE_END_DATE;
	}

	public int getQuotation_Save_id() {
		return Quotation_Save_id;
	}

	public void setQuotation_Save_id(int quotation_Save_id) {
		Quotation_Save_id = quotation_Save_id;
	}

	public String getQuotation_id() {
		return Quotation_id;
	}

	public void setQuotation_id(String quotation_id) {
		Quotation_id = quotation_id;
	}

	public int getScreen_No() {
		return Screen_No;
	}

	public void setScreen_No(int screen_No) {
		Screen_No = screen_No;
	}

	public int getVERSION_NO() {
		return VERSION_NO;
	}

	public void setVERSION_NO(int vERSION_NO) {
		VERSION_NO = vERSION_NO;
	}

	public String getJSON_DATA() {
		return JSON_DATA;
	}

	public void setJSON_DATA(String jSON_DATA) {
		JSON_DATA = jSON_DATA;
	}

	public Date getCREATION_TIME() {
		return CREATION_TIME;
	}

	public void setCREATION_TIME(Date cREATION_TIME) {
		CREATION_TIME = cREATION_TIME;
	}

	public String getCREATED_BY() {
		return CREATED_BY;
	}

	public void setCREATED_BY(String cREATED_BY) {
		CREATED_BY = cREATED_BY;
	}

	public Date getUPDATED_TIME() {
		return UPDATED_TIME;
	}

	public void setUPDATED_TIME(Date uPDATED_TIME) {
		UPDATED_TIME = uPDATED_TIME;
	}

	public String getUPDATED_BY() {
		return UPDATED_BY;
	}

	public void setUPDATED_BY(String uPDATED_BY) {
		UPDATED_BY = uPDATED_BY;
	}

	public Date getEFFECTIVE_END_DATE() {
		return EFFECTIVE_END_DATE;
	}

	public void setEFFECTIVE_END_DATE(Date eFFECTIVE_END_DATE) {
		EFFECTIVE_END_DATE = eFFECTIVE_END_DATE;
	}

	@Override
	public String toString() {
		return "T_QUOTATION_SAVE [Quotation_Save_id=" + Quotation_Save_id + ", Quotation_id=" + Quotation_id
				+ ", Screen_No=" + Screen_No + ", VERSION_NO=" + VERSION_NO + ", JSON_DATA=" + JSON_DATA
				+ ", CREATION_TIME=" + CREATION_TIME + ", CREATED_BY=" + CREATED_BY + ", UPDATED_TIME=" + UPDATED_TIME
				+ ", UPDATED_BY=" + UPDATED_BY + ", EFFECTIVE_END_DATE=" + EFFECTIVE_END_DATE + "]";
	}
	
	// === JSON PARSING LOGIC AND NEW GETTERS ===
	
	/**
	 * Private helper method to parse the JSON data once.
	 */
	private JsonNode parseJsonData() {
		if (JSON_DATA == null || JSON_DATA.isEmpty()) {
			return null;
		}
		try {
			return OBJECT_MAPPER.readTree(JSON_DATA);
		} catch (JsonProcessingException e) {
			System.err.println("Error parsing JSON_DATA for Quotation_id: " + Quotation_id);
			// e.printStackTrace(); // Keep commented out unless needed for deep debugging
			return null;
		}
	}
	
	/**
	 * Generic helper to extract a text value from the JSON.
	 */
	public String getValueFromJson(String fieldName) {
		JsonNode root = parseJsonData();
		if (root != null && root.has(fieldName)) {
			// Check if the value is null or "null" string
			JsonNode node = root.get(fieldName);
			if (node.isNull() || "null".equalsIgnoreCase(node.asText())) {
				return null;
			}
			return node.asText();
		}
		return null;
	}
	
	// --- PUBLIC GETTERS FOR PDF DATA (JSON) ---
	
	// PERSONAL INFORMATION GETTERS
	@Transient
	public String getProspectName() {
		// Example key: adjust if your JSON uses a different key like "nameOfPolicyHolder"
        System.out.println(getValueFromJson("insuredFirstName"));
        return getValueFromJson("insuredFirstName") + " " + getValueFromJson("insuredSurName");
	}
	
	@Transient
	public String getAge() {
		// Ensure the JSON key matches your stored age field (e.g., "ageInYears")
		return getValueFromJson("age"); 
	}
	
	@Transient
	public String getGender() {
		return getValueFromJson("gender");
	}
	
	@Transient
	public String getInstallmentPremium() {
		return getValueFromJson("basicPlanPremium");
	}
	
	@Transient
	public String getPaymentMode() {
		return getValueFromJson("paymentMode");
	}

	// PRODUCT INFORMATION GETTERS
	
	@Transient
	public String getTagLine() {
		return getValueFromJson("tagLine");
	}
	
	@Transient
	public String getUinNumber() {
		return getValueFromJson("uin");
	}
	
	@Transient
	public String getGstRate() {
		return getValueFromJson("gstRate");
	}
	
	@Transient
	public String getState() {
		return getValueFromJson("state");
	}
	// === NEW GETTERS FOR SOURCE PDF MATCHING ===

    @Transient
    public String getPrimaryLifeAssured() {
        // Usually same as prospect for single life, but checking JSON
        String val = getValueFromJson("primaryLifeAssured");
        return val != null ? val : getProspectName();
    }

    @Transient
    public String getPolicyOption() {
        return getValueFromJson("policyOption");
    }

    @Transient
    public String getReturnOfPremium() {
        return getValueFromJson("returnOfPremium");
    }

    @Transient
    public String getSumAssured() {
        return getValueFromJson("basicSumInsured");
    }
    
    @Transient
    public String getSumAssuredOnDeath() {
        // Often same as Sum Assured in simple plans
        String val = getValueFromJson("sumAssuredOnDeath");
        return val != null ? val : getSumAssured();
    }
 // Inside QuoteDetails.java
    @Transient public String getPolicyTerm() { return getValueFromJson("policyTerm"); }
    @Transient public String getPremiumPaymentTerm() { return getValueFromJson("premiumPaymentTerm"); }
    @Transient public String getPremiumAmount() { return getValueFromJson("basicPlanPremium"); }
    @Transient public String getModeOfPayment() { return getValueFromJson("modeOfPayment"); }
    @Transient public String getProposalNo() { return getValueFromJson("proposalNo"); }
    @Transient public String getProductName() { return getValueFromJson("Product"); }
    @Transient public String getRiskClass() { return getValueFromJson("riskClass"); }
    @Transient public String getProspectAge() { return getValueFromJson("prospectAge"); }
    @Transient public String getProspectGender() { return getValueFromJson("prospectGender"); }
    @Transient public String getPrimaryAssuredAge() { return getValueFromJson("primaryAssuredAge"); }
    @Transient public String getPrimaryAssuredGender() { return getValueFromJson("primaryAssuredGender"); }
}