package com.eapp.entity.role;

import java.util.Date;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name = "T_USER")
public class TUser {

    @Id
    @Column(name = "EMAIL")
    private String email;

    @Column(name = "USER_NAME")
    private String userName;

    @Column(name = "PASSWORD")
    private String password;

    @Temporal(TemporalType.DATE)
    @Column(name = "EFF_START_DATE")
    private Date effStartDate;

    @Temporal(TemporalType.DATE)
    @Column(name = "EFF_END_DATE")
    private Date effEndDate;

    // Direct mapping to roles
    @ManyToMany
    @JoinTable(
            name = "T_ROLE_USER",
            joinColumns = @JoinColumn(name = "EMAIL"),
            inverseJoinColumns = @JoinColumn(name = "ROLE_CODE")
    )
    private List<Role> roles;

    public TUser() {}

    public TUser(String email, String userName, String password, Date effStartDate, Date effEndDate) {
        this.email = email;
        this.userName = userName;
        this.password = password;
        this.effStartDate = effStartDate;
        this.effEndDate = effEndDate;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public Date getEffStartDate() { return effStartDate; }
    public void setEffStartDate(Date effStartDate) { this.effStartDate = effStartDate; }

    public Date getEffEndDate() { return effEndDate; }
    public void setEffEndDate(Date effEndDate) { this.effEndDate = effEndDate; }

    public List<Role> getRoles() { return roles; }
    public void setRoles(List<Role> roles) { this.roles = roles; }
}
