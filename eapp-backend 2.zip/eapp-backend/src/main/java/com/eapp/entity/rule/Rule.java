package com.eapp.entity.rule;

import com.eapp.entity.role.Role;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "T_RULE")
public class Rule {

    @Id
    @Column(name = "RULE_CODE")
    private String ruleCode;

    @Column(name = "STEP")
    private Integer step;

    @ManyToOne
    @JoinColumn(name = "VALIDATION", referencedColumnName = "V_RULE_CODE")
    private RuleDef validation;

    @ManyToOne
    @JoinColumn(name = "ASSIGN_TO", referencedColumnName = "ROLE_CODE")
    private Role assignTo;

    public Rule() {}

    public Rule(String ruleCode, int step, RuleDef validation, Role assignTo) {
        this.ruleCode = ruleCode;
        this.step = step;
        this.validation = validation;
        this.assignTo = assignTo;
    }

    public String getRuleCode() {
        return ruleCode;
    }

    public void setRuleCode(String ruleCode) {
        this.ruleCode = ruleCode;
    }

    public Integer getStep() {
        return step != null ? step : 0;
    }


    public void setStep(int step) {
        this.step = step;
    }

    public RuleDef getValidation() {
        return validation;
    }

    public void setValidation(RuleDef validation) {
        this.validation = validation;
    }

    public Role getAssignTo() {
        return assignTo;
    }

    public void setAssignTo(Role assignTo) {
        this.assignTo = assignTo;
    }
}
