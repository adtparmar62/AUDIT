package com.eapp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "mib_table")
public class MibTable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	@Column(name = "SSN", nullable = false)
	private String ssn;

	@Column(name = "MIB_CODE", nullable = false)
	private String mibCode;

	// Default Constructor
	public MibTable() {
	}

	// Parameterized Constructor
	public MibTable(String ssn, String mibCode) {
		this.ssn = ssn;
		this.mibCode = mibCode;
	}

	// Getters and Setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getMibCode() {
		return mibCode;
	}

	public void setMibCode(String mibCode) {
		this.mibCode = mibCode;
	}
}
