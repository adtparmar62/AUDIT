package com.eapp.dto.reponseDTO;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BatchRequirementsDTO {

    @JsonProperty("txnTypeId")
    private String txnTypeId; // Maps to Application Number / Case ID

    @JsonProperty("rows")
    private List<RequirementItem> rows;

    public static class RequirementItem {
        private String requirementName;
        private String requirementType;
        private String requirementRequestDate;
        private String requestedBy;
        private String status;
        private String dateReceived;
        private String receivedFrom;
        private String attachment;

        // Getters and Setters
        public String getRequirementName() { return requirementName; }
        public void setRequirementName(String requirementName) { this.requirementName = requirementName; }
        public String getRequirementType() { return requirementType; }
        public void setRequirementType(String requirementType) { this.requirementType = requirementType; }
        public String getRequirementRequestDate() { return requirementRequestDate; }
        public void setRequirementRequestDate(String date) { this.requirementRequestDate = date; }
        public String getRequestedBy() { return requestedBy; }
        public void setRequestedBy(String requestedBy) { this.requestedBy = requestedBy; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
        public String getAttachment() { return attachment; }
        public void setAttachment(String attachment) { this.attachment = attachment; }
    }

    public String getTxnTypeId() { return txnTypeId; }
    public void setTxnTypeId(String txnTypeId) { this.txnTypeId = txnTypeId; }
    public List<RequirementItem> getRows() { return rows; }
    public void setRows(List<RequirementItem> rows) { this.rows = rows; }
}