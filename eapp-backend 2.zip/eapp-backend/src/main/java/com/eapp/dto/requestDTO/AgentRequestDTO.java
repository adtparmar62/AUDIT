package com.eapp.dto.requestDTO;

public class AgentRequestDTO {

    private String quotation_no;
    private String agent;

    public String getQuotation_no() {
        return quotation_no;
    }

    public void setQuotation_no(String quotation_no) {
        this.quotation_no = quotation_no;
    }

    public String getAgent() {
        return agent;
    }

    public void setAgent(String agent) {
        this.agent = agent;
    }
}