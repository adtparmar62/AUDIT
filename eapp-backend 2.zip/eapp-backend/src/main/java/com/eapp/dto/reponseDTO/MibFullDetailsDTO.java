package com.eapp.dto.reponseDTO;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MibFullDetailsDTO {

    @JsonProperty("ssn")
    private String ssn;

    @JsonProperty("mib_code")
    private String mibCode;

    @JsonProperty("lookup_value")
    private String lookupValue;

    @JsonProperty("lookup_name")
    private String lookupName;

    // Constructor
    public MibFullDetailsDTO(String ssn, String mibCode, String lookupValue, String lookupName) {
        this.ssn = ssn;
        this.mibCode = mibCode;
        this.lookupValue = lookupValue;
        this.lookupName = lookupName;
    }

    // Getters
    public String getSsn() { return ssn; }
    public String getMibCode() { return mibCode; }
    public String getLookupValue() { return lookupValue; }
    public String getLookupName() { return lookupName; }
}