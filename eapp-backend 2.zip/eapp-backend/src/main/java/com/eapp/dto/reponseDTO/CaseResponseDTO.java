package com.eapp.dto.reponseDTO;

import com.eapp.entity.CaseDetails;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CaseResponseDTO {

    @JsonProperty("Response")
    private ResponseWrapper response;

    public CaseResponseDTO(CaseDetails caseDetails) {
        this.response = new ResponseWrapper(caseDetails);
    }

    public static class ResponseWrapper {
        @JsonProperty("CaseDetails")
        private CaseDetails caseDetails;

        // Note: PartyDetails is removed from here

        public ResponseWrapper(CaseDetails caseDetails) {
            this.caseDetails = caseDetails;
        }

        public CaseDetails getCaseDetails() { return caseDetails; }
    }

    public ResponseWrapper getResponse() { return response; }
}