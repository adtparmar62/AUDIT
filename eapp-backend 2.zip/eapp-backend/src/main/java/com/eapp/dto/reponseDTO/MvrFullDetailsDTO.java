package com.eapp.dto.reponseDTO;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MvrFullDetailsDTO {

    @JsonProperty("dl")
    private String dl;

    @JsonProperty("penalty_code")
    private String penaltyCode;

    @JsonProperty("penalty_description")
    private String penaltyDescription;

    @JsonProperty("category")
    private String category;

    // Constructor
    public MvrFullDetailsDTO(String dl, String penaltyCode, String penaltyDescription, String category) {
        this.dl = dl;
        this.penaltyCode = penaltyCode;
        this.penaltyDescription = penaltyDescription;
        this.category = category;
    }

    // Getters
    public String getDl() { return dl; }
    public String getPenaltyCode() { return penaltyCode; }
    public String getPenaltyDescription() { return penaltyDescription; }
    public String getCategory() { return category; }
}