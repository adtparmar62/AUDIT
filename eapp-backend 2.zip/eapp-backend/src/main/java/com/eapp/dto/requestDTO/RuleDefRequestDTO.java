package com.eapp.dto.requestDTO;

import lombok.Data;

@Data
public class RuleDefRequestDTO {
    private String workCode;
    public String getWorkCode() {
		return workCode;
	}
	public void setWorkCode(String workCode) {
		this.workCode = workCode;
	}
	public String getQuoteId() {
		return quoteId;
	}
	public void setQuoteId(String quoteId) {
		this.quoteId = quoteId;
	}
	private String quoteId;
}
