
package com.eapp.dto;

public class SparkPolicyResult {
    private String policyId;
    private Long uwIdUsed; // null if no content for this policyId
    private String sparkOutput; // null if no content

    public SparkPolicyResult() {
    }

    public SparkPolicyResult(String policyId, Long uwIdUsed, String sparkOutput) {
        this.policyId = policyId;
        this.uwIdUsed = uwIdUsed;
        this.sparkOutput = sparkOutput;
    }

    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    public Long getUwIdUsed() {
        return uwIdUsed;
    }

    public void setUwIdUsed(Long uwIdUsed) {
        this.uwIdUsed = uwIdUsed;
    }

    public String getSparkOutput() {
        return sparkOutput;
    }

    public void setSparkOutput(String sparkOutput) {
        this.sparkOutput = sparkOutput;
    }
}
