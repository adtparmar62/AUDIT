package com.eapp.dto.requestDTO;

public class SparkTokenRequestDTO {

	private String sparkToken;

	public String getSparkToken() {
		return sparkToken;
	}

	public void setSparkToken(String sparkToken) {
		this.sparkToken = sparkToken;
	}

}
