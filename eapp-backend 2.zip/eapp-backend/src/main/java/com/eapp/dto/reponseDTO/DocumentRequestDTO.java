package com.eapp.dto.reponseDTO;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DocumentRequestDTO {

    @JsonProperty("RequestPayload")
    private Payload requestPayload;

    public static class Payload {
        @JsonProperty("RequirementName")
        private String requirementName;
        
        @JsonProperty("fileName")
        private String fileName;
        
        @JsonProperty("base64string")
        private String base64string;
        
        @JsonProperty("ApplicationNumber")
        private String applicationNumber;

        // Getters and Setters
        public String getRequirementName() { return requirementName; }
        public void setRequirementName(String requirementName) { this.requirementName = requirementName; }

        public String getFileName() { return fileName; }
        public void setFileName(String fileName) { this.fileName = fileName; }

        public String getBase64string() { return base64string; }
        public void setBase64string(String base64string) { this.base64string = base64string; }

        public String getApplicationNumber() { return applicationNumber; }
        public void setApplicationNumber(String applicationNumber) { this.applicationNumber = applicationNumber; }
    }

    public Payload getRequestPayload() { return requestPayload; }
    public void setRequestPayload(Payload requestPayload) { this.requestPayload = requestPayload; }
}