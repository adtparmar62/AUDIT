package com.eapp.dto.requestDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PolicySubmitRequestDTO {
    public String getPolicyId() {
		return policyId;
	}
	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}
//	public double getSa() {
//		return sa;
//	}
//	public void setSa(double sa) {
//		this.sa = sa;
//	}
//	public double getPeriodPrem() {
//		return periodPrem;
//	}
//	public void setPeriodPrem(double periodPrem) {
//		this.periodPrem = periodPrem;
//	}
//	public double getNormalPrem() {
//		return normalPrem;
//	}
//	public void setNormalPrem(double normalPrem) {
//		this.normalPrem = normalPrem;
//	}
	private String policyId;
	private String jsonData;
//    private double sa;
//    private double periodPrem;
//    private double normalPrem;
	public String getJsonData() {
		return jsonData;
	}
	public void setJsonData(String jsonData) {
		this.jsonData = jsonData;
	}
}
