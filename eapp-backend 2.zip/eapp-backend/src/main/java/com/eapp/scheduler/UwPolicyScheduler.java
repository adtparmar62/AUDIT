package com.eapp.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.eapp.service.UwPolicyService;

@Component
public class UwPolicyScheduler {

    @Autowired
    private UwPolicyService uwPolicyService;

    @Autowired
    private SchedulerService schedulerService;

    // Cron expression: every 30 seconds
    // Format: second, minute, hour, day of month, month, day(s) of week
    @Scheduled(cron = "*/30 * * * * *")
    public void runPolicyCheckJob() {
        // If the frontend has switched to Batch Mode, skip execution entirely
        if (!schedulerService.isEnabled()) {
            System.out.println("Cron Job skipped — Scheduler is currently disabled.");
            return;
        }

        System.out.println("Starting Cron Job: Checking t_uw_policy table...");
        uwPolicyService.processAutoToManualPolicies();
        System.out.println("Cron Job Finished.");
    }
}