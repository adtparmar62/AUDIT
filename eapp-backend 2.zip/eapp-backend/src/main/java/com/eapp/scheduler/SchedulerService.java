package com.eapp.scheduler;

import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicBoolean;


@Service
public class SchedulerService {


    private final AtomicBoolean enabled = new AtomicBoolean(true);

    public void disable() {
        enabled.set(false);
        System.out.println("Scheduler disabled");
    }

    public void enable() {
        enabled.set(true);
        System.out.println("Scheduler enabled");
    }

    public boolean isEnabled() {
        return enabled.get();
    }
}