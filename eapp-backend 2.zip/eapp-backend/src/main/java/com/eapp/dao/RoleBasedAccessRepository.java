
package com.eapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eapp.entity.role.Role;

@Repository
public interface RoleBasedAccessRepository extends JpaRepository<Role, String> {

   
}
