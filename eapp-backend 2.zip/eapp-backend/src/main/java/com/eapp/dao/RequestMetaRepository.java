
// src/main/java/com/eapp/dao/RequestMetaRepository.java
package com.eapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.eapp.service.spark.RequestMeta;

public interface RequestMetaRepository extends JpaRepository<RequestMeta, String> {

    // Optional<RequestMeta> findTopByOrderByIdAsc();

    @Query(value = "SELECT * FROM t_metadata LIMIT 1", nativeQuery = true)
    RequestMeta fetchOne();
}
