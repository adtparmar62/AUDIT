package com.eapp.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eapp.entity.Party;

public interface PartyRepos extends JpaRepository<Party, Long> {
	
	// This looks for the CASE_ID inside the CaseDetails object in Party entity
    Optional<Party> findByCaseDetails_CaseId(Long caseId);

}
