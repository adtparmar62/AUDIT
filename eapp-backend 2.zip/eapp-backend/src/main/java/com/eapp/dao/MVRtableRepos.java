package com.eapp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.eapp.dto.reponseDTO.MvrFullDetailsDTO;
import com.eapp.entity.MVRtable;

@Repository
public interface MVRtableRepos extends JpaRepository<MVRtable, Long> {
    
    List<MVRtable> findByDl(String dl);

    @Query("SELECT new com.eapp.dto.reponseDTO.MvrFullDetailsDTO(m.dl, m.penaltyCode, l.lookupValue, l.lookupName) " +
    	       "FROM MVRtable m " +
    	       "JOIN MasterLookup l ON m.penaltyCode = l.lookupCode " +
    	       "WHERE m.dl = :dl")
    	List<MvrFullDetailsDTO> getDetailedMvrByDl(@Param("dl") String dl);
}