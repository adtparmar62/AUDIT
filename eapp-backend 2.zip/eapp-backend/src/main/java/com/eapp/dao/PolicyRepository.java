package com.eapp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.eapp.entity.Policy;

@Repository
public interface PolicyRepository extends JpaRepository<Policy, String> {

    List<Policy> findByStateId(int stateId);

    List<Policy> findByAssignRole(String assignRole);
    
    @Query(value = """
            SELECT tp.*
            FROM t_policy tp
            JOIN t_role_user tru
              ON tp.assign_role = tru.role_code
            WHERE tp.state_id = 1
              AND tru.email = :email
            """, nativeQuery = true)
    List<Policy> findPoliciesByRoleEmail(@Param("email") String email);

    @Query(value = """
            SELECT tp.*
            FROM t_policy tp
            JOIN t_role_user tru
              ON tp.assign_role = tru.role_code
            WHERE tp.state_id = 2
              AND tru.email = :email
            """, nativeQuery = true)
    List<Policy> findPoliciesByRoleEmailProofing(@Param("email") String email);

}