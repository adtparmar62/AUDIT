package com.eapp.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eapp.entity.UwRequirement;

@Repository
public interface UwRequirementRepos extends JpaRepository<UwRequirement, Long> {

    List<UwRequirement> findByCaseId(String caseId);

    List<UwRequirement> findByApplicationNumber(String applicationNumber);

    // NEW METHOD: Find specific requirement for a specific application
    // This prevents overwriting the wrong row in your table
    Optional<UwRequirement> findTopByApplicationNumberAndRequirementName(String applicationNumber,
            String requirementName);
}