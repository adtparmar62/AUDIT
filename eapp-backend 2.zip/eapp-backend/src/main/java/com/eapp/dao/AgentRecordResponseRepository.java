package com.eapp.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eapp.entity.rule.AgentRecordResponse;

@Repository
public interface AgentRecordResponseRepository extends JpaRepository<AgentRecordResponse, String> {

    Optional<AgentRecordResponse> findByQuotationNoAndAgent(String quotationNo, String agent);
}
