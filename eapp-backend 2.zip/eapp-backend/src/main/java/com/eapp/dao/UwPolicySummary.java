package com.eapp.dao;

public interface UwPolicySummary {
    Long getUwid();
    String getPolicyId();
    Integer getStateId();
    Double getSa();
    Double getPeriodPrem();
    String getProduct();
    String getAssignRole();
    String getFirstName();
    String getLastName();
    String getProductJson();
    String getSumAssuredJson();
    String getPeriodPremJson();
}
