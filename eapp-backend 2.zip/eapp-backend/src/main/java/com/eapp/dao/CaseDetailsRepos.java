package com.eapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eapp.entity.CaseDetails;

public interface CaseDetailsRepos extends JpaRepository<CaseDetails, Long> {

}
