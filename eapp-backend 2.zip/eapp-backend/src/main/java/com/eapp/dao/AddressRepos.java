package com.eapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eapp.entity.Address;

public interface AddressRepos extends JpaRepository<Address, Long> {

}
