package com.eapp.dao;
 
import org.springframework.data.jpa.repository.JpaRepository;

import com.eapp.entity.rule.Work;
 
public interface WorkRepos extends JpaRepository<Work, String> {
	
	
 
}