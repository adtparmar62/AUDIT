package com.eapp.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.eapp.entity.QuoteDetails;


public interface QuoteDetailsRepos extends JpaRepository<QuoteDetails, Integer> {

	@Query("select t from t_quotation_save t  where \r\n"
			+ "Quotation_id=:quoationId and Screen_No = :screenNo and\r\n"
			+ "VERSION_NO=(\r\n"
			+ "select max(VERSION_NO) from t_quotation_save \r\n"
			+ "where Quotation_id=:quoationId and Screen_No = :screenNo\r\n"
			+ "group by Quotation_id,Screen_No )")
	Optional<QuoteDetails> findDetailsWithLatestVersionNo(String quoationId, int screenNo);
	
	@Query("select t from t_quotation_save t where t.Screen_No=0")
	List<QuoteDetails> pullQuotes();

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO t_uw_policy (policy_id, uw_status, content) " +
				   "SELECT Quotation_id, 1, JSON_DATA FROM t_quotation_save " +
				   "WHERE Screen_No = 0 " +
				   "AND NOT EXISTS (SELECT 1 FROM t_uw_policy WHERE policy_id = Quotation_id)",
		   nativeQuery = true)
	void bulkPullQuotes();

}
