package com.eapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eapp.entity.CoverageFields;
import com.eapp.entity.CoverageFieldsId;

public interface CoverageFieldsRepos extends JpaRepository<CoverageFields, CoverageFieldsId> {

}
