package com.eapp.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.eapp.entity.UwPolicy;

@Repository
public interface UwPolicyRepository extends JpaRepository<UwPolicy, Long> {

    @Query(value = """
          SELECT tup.*
          FROM t_uw_policy AS tup
          JOIN t_policy     AS tp  ON tp.policy_id  = tup.policy_id
          WHERE tp.state_id = 3
            AND EXISTS (
              SELECT 1
              FROM t_role_user AS tru
              WHERE tru.role_code = tup.assign_role
                AND tru.email = :email
            )
          """, nativeQuery = true)

    List<UwPolicy> findUwByRoleEmail(@Param("email") String email);
    @Query(value = "select * from t_uw_policy where policy_id = :policyId order by uw_id desc limit 1", nativeQuery = true)
    UwPolicy findByPolicyId(String policyId);
    @Query(value = "SELECT DISTINCT policy_id FROM t_uw_policy", nativeQuery = true)
    List<String> findDistinctPolicyIdsAll();
    

    // NEW: get latest (highest uwid) row for a policy_id where content IS NOT NULL
    Optional<UwPolicy> findTopByPolicyIdAndContentIsNotNullOrderByUwidDesc(String policyId);

    // NEW: Find policies waiting for manual UW transition
    @Query(value = """
            SELECT * FROM t_uw_policy 
            WHERE uw_status = '9' 
           
            """, nativeQuery = true)
    List<UwPolicy> findPendingManualPoliciesWithStatus8();
    @Query(value = """
            SELECT * FROM t_uw_policy 
            WHERE uw_status = '3' 
            AND output_data LIKE '%"Auto_UW_Outcome":"Manual UW needed"%'
            """, nativeQuery = true)
        List<UwPolicy> findPendingManualPolicies();

        @Query(value = """
            SELECT * FROM t_uw_policy
            WHERE uw_status = '7'
            """, nativeQuery = true)
        List<UwPolicy> findPendingManualPoliciesWithStatus6();

    @Query(value = "SELECT tup.uw_id as uwid, tup.policy_id as policyId, tup.uw_status as stateId, " +
                   "tup.sa, tup.period_prem as periodPrem, tup.product_name as product, tup.assign_role as assignRole, " +
                   "COALESCE(JSON_UNQUOTE(JSON_EXTRACT(tup.content, '$.lifeAssured.insuredFirstName')), '') as firstName, " +
                   "COALESCE(JSON_UNQUOTE(JSON_EXTRACT(tup.content, '$.lifeAssured.insuredSurName')), '') as lastName, " +
                   "COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(qs.JSON_DATA, '$.basicPlan')), 'null'), tup.product_name, '') as productJson, " +
                   "COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(tup.content, '$.planDetails.basicSumInsured')), 'null'), '0') as sumAssuredJson, " +
                   "COALESCE(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(qs.JSON_DATA, '$.basicPlanPremium')), 'null'), '0') as periodPremJson " +
                   "FROM t_uw_policy tup " +
                   "LEFT JOIN t_quotation_save qs ON qs.Quotation_id = tup.policy_id " +
                   "AND qs.Screen_No = 2 AND qs.EFFECTIVE_END_DATE IS NULL", nativeQuery = true)
    List<UwPolicySummary> findAllSummary();

    }

