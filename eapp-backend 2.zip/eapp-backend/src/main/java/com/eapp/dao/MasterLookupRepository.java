package com.eapp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eapp.entity.MasterLookup;

@Repository
public interface MasterLookupRepository extends JpaRepository<MasterLookup, String> {
    
    // Allows you to filter by category (e.g., MIB, GENDER, etc.)
    List<MasterLookup> findByLookupName(String lookupName);
}
