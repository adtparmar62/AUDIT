package com.eapp.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.eapp.dto.reponseDTO.MibFullDetailsDTO;
import com.eapp.entity.MibTable;

@Repository
public interface MibTableRepos extends JpaRepository<MibTable, Long> {
    
    List<MibTable> findBySsn(String ssn);

    // FIXED: Added .reponseDTO to the package path in the query string
    @Query("SELECT new com.eapp.dto.reponseDTO.MibFullDetailsDTO(m.ssn, m.mibCode, l.lookupValue, l.lookupName) " +
           "FROM MibTable m " +
           "JOIN MasterLookup l ON m.mibCode = l.lookupCode " +
           "WHERE m.ssn = :ssn")
    List<MibFullDetailsDTO> getDetailedMibBySsn(@Param("ssn") String ssn);
}