package com.eapp.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eapp.entity.SparkTokenEntity;

public interface SparkTokenRepository extends JpaRepository<SparkTokenEntity, Long> {
    Optional<SparkTokenEntity> findTopByOrderByIdDesc();
    
}