package com.eapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eapp.entity.TransactionDetailSequence;

public interface TransactionDetailSequenceRepos extends JpaRepository<TransactionDetailSequence, Integer> {

}
