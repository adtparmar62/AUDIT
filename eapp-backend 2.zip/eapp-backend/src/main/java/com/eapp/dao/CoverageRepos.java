package com.eapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eapp.entity.Coverage;

public interface CoverageRepos extends JpaRepository<Coverage, Long> {

}
