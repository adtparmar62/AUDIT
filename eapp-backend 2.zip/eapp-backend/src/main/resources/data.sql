-- Insert roles
INSERT IGNORE INTO t_role (role_code, role_desc, role_name) VALUES
('R001','ADMIN','ADMIN can access all modules and create other users'),
('R002','Sr_UW','Senior Underwriter'),
('R003','UW','Underwriter'),
('R004','Jr_UW','Junior Underwriter'),
('R005','Case_Manager','Case Manager'),
('R006','User','User');

-- Insert work
INSERT IGNORE INTO t_work (work_code, work_type, work_desc) VALUES
('W021225-1', 'Generate Quote', 'Generate Quote'),
('W021225-2', 'Get Feedback on Quote', 'Get Feedback on Quote'),
('W021225-3', 'Quote UWR', 'Quote UWR'),
('W021225-4', 'UWR Negotiation', 'UWR Negotiation');

-- Insert rule definitions FIRST
INSERT IGNORE INTO t_rule_def (v_rule_code, rule_definition) VALUES
('VRULE_005', 'if value is > 5000 then assign to UWR pool (Role UW). elseif value is > 10000 then assign to Sr UWR pool (Role Sr_UW). else Jr UWR pool (Role Jr_UW).');

-- Insert rules
INSERT IGNORE INTO t_rule (rule_code, step, validation, assign_to) VALUES
('RULE_001', 0, NULL, 'R005'),
('RULE_002', 1, 'VRULE_005', NULL),
('RULE_003', 2, NULL, 'R002'),
('RULE_006', 1, NULL, NULL),
('RULE_007', 1, NULL, 'R003');

-- Insert workwise rules
INSERT IGNORE INTO t_workwise_rule (work_code, rule_code) VALUES
('W021225-1', 'RULE_002'),
('W021225-3', 'RULE_007'),
('W021225-3', 'RULE_001'),
('W021225-3', 'RULE_006');
