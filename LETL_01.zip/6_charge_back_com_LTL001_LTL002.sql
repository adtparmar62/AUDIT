declare
 m_comm_id NUMBER(10) ;
begin
  ---LETL002 (SIO)
  select max (COMM_ID) into m_comm_id from T_CHARGEBACK_COMM_RATE; 
  insert into T_CHARGEBACK_COMM_RATE (COMM_ID, PRODUCT_ID, COMMISION_TYPE_ID, MONTHS_START, MONTHS_END, RATE) values (m_comm_id + 1, 5808, 1, 0, 6, 1.0000);
  insert into T_CHARGEBACK_COMM_RATE (COMM_ID, PRODUCT_ID, COMMISION_TYPE_ID, MONTHS_START, MONTHS_END, RATE) values (m_comm_id + 2, 5808, 1, 6, 12, 0.5);
  ---LETL001 (Full UW)
  insert into T_CHARGEBACK_COMM_RATE (COMM_ID, PRODUCT_ID, COMMISION_TYPE_ID, MONTHS_START, MONTHS_END, RATE) values (m_comm_id + 3, 5804, 1, 0, 6, 1.0000);
  insert into T_CHARGEBACK_COMM_RATE (COMM_ID, PRODUCT_ID, COMMISION_TYPE_ID, MONTHS_START, MONTHS_END, RATE) values (m_comm_id + 4, 5804, 1, 6, 12, 0.5);
  
  insert into t_standalone_info (PRODUCT_ID, STANDALONE_TYPE_ID, PRODUCT_ID_MAX) values (5804, 2, null);  
  insert into t_standalone_info (PRODUCT_ID, STANDALONE_TYPE_ID, PRODUCT_ID_MAX) values (5808, 2, null);  
end;  

--select * FROM t_standalone_info ii where ii.product_id in (5804,5808);
--select * FROM t_chargeback_comm_rate pp where pp.product_id in (5804,5808);



