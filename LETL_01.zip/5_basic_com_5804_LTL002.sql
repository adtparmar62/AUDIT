--basic com --HDB01
delete from t_commision tc where tc.vendor = 'HDB01' and tc.product_id in (5804);
insert into t_commision
  select 5804 product_id,
         tc.premium_year,
         tc.period,
         tc.age,
         tc.year,
         tc.start_date,
         tc.end_date,
         tc.commision_rate,
         tc.agent_cate,
         tc.organ_id,
         tc.branch_bank,
         tc.commision_type_id,
         tc.derivation,
         tc.fee_type,
         tc.calc_type,
         tc.commision_months,
         tc.low_age,
         tc.high_age,
         '100003HDB01'
    FROM t_commision tc
   where tc.vendor = 'N'
     and tc.product_id in (5704);

update t_commision tc set tc.commision_rate = 0.4 where tc.vendor = '100003HDB01'  and tc.product_id in (5804) and tc.year = 1;
update t_commision tc set tc.commision_rate = 0.2 where tc.vendor = '100003HDB01'  and tc.product_id in (5804) and tc.year = 2;
update t_commision tc set tc.commision_rate = 0.15 where tc.vendor = '100003HDB01'  and tc.product_id in (5804) and tc.year in (3,4,5);
update t_commision tc set tc.commision_rate = 0 where tc.vendor = '100003HDB01'  and tc.product_id in (5804) and tc.year > 5;

--select * FROM t_commision tc where tc.product_id = 5804
