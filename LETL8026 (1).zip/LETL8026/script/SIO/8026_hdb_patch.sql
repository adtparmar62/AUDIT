-- ============================================================
-- LETL002 (SIO) - HDB PROJECT PARTNER PATCH
-- PRODUCT_ID : 8026
-- Channel    : HDB (bancassurance / online sales platform)
-- Pay mode   : Yearly ONLY (override generic multi-mode)
-- FA limits  : 18-55 -> 100M-2B, 56-70 -> 100M-1B
-- ============================================================

-- Remove generic FA limit rows for this partner context
delete from t_proposal_amount_limit where product_id = 8026 and product_partner = 'HDB';

-- HDB age-banded FA limits per spec
insert into t_proposal_amount_limit (PRODUCT_ID, PRODUCT_PARTNER, AGE_FROM, AGE_TO, MIN_AMOUNT, MAX_AMOUNT)
values (8026, 'HDB', 18, 55, 100000000, 2000000000);

insert into t_proposal_amount_limit (PRODUCT_ID, PRODUCT_PARTNER, AGE_FROM, AGE_TO, MIN_AMOUNT, MAX_AMOUNT)
values (8026, 'HDB', 56, 70, 100000000, 1000000000);

-- HDB: yearly payment mode only (remove monthly/quarterly/half-yearly for HDB channel)
delete from T_PRODUCT_CHARGE where product_id = 8026 and model_type = 'HDB';

insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '1', 1.000000, 'HDB'); -- Annual only

-- HDB commission (already in main DML as primary commission table)
-- Note: Vikki commission is TBU per spec - placeholder below

COMMIT;
