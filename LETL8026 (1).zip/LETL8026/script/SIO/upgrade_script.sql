whenever oserror exit rollback
whenever sqlerror exit rollback
set define off
set feedback on
set echo on
SET TERMOUT on
spool upgrade_script.log
@@LETL8026_DDL_1.sql
@@8026_dml.sql
@@8026_pro_dml.sql
@@LETL8026_DDL_2.sql
commit;
spool off
