-- ============================================================
-- LEVEL TERM LIFE - SIO (LETL002)
-- PRODUCT_ID : 8026
-- PRODUCT_CODE: LETL002
-- GENERATED   : 2026-06-03
-- ============================================================

-- ============================================================
-- STEP 1: DELETE EXISTING DATA (idempotent re-run safety)
-- ============================================================
delete from t_product_guarantee_rate   where product_id  = 8026;
delete from t_replacement_product       where replacement_product_id = 8026;
delete from t_prt_main_product          where main_product_id = 8026;
delete from t_db_fa_rate                where product_id  = 8026;
delete from t_proposal_amount_limit     where product_id  = 8026;
delete from T_PRT_MAIN_RIDER            where mainproduct_id = 8026;
delete from T_SURRENDER_FEE             where product_id  = 8026;
delete from T_PARTIAL_SURR_FEE          where product_id  = 8026;
delete from T_PROD_ACC_CFG              where product_id  = 8026;
delete from T_PROD_ACC_ATT_CFG          where product_id  = 8026;
delete from T_MAIN_RIDER                where main_id     = 8026;
delete from T_MOTALITY_FEE              where product_id  = 8026;
delete from T_TARGET_EXTRA_FEE          where product_id  = 8026;
delete from T_PREMIUM_RATE              where product_id  = 8026;
delete from T_TARGET_OCC_CLASS_FACTOR   where product_id  = 8026;
delete from T_PROD_TARGET_PERIOD        where product_id  = 8026;
delete from T_PROD_TARGET_CHK           where product_id  = 8026;
delete from T_PROD_TARGET               where product_id  = 8026;
delete from T_CHARGE_FEE                where product_id  = 8026;
delete from T_COMMISION                 where product_id  = 8026;
delete from T_PAY_LIABILITY             where product_id  = 8026;
delete from T_LIAB_PAY_RELATIVE         where product_id  = 8026;
delete from T_LIAB_PAY_PARAM            where product_id  = 8026;
delete from T_LIABILITY_CONFIG          where product_id  = 8026;
delete from T_PRODUCT_SURRENDER         where product_id  = 8026;
delete from T_PRODUCT_CHARGE            where product_id  = 8026;
delete from T_ISSUE_FEE                 where product_id  = 8026;
delete from T_UNIT_AMOUNT               where product_id  = 8026;
delete from T_LIFE_BASIC                where product_id  = 8026;
delete from t_product_distri_type       where product_id  = 8026;
delete from t_target_permille_factor    where product_id  = 8026;
delete from T_PRODUCT_LIFE              where product_id  = 8026;
delete from T_CASH_VALUE                where product_id  = 8026;
delete from T_CALCU_LIMIT               where product_id  = 8026;
delete from T_PAY_TYPE_CONVERTION       where product_id  = 8026;
delete from T_LIAB_ACCUTOR_DEF          where product_id  = 8026;
delete from T_ACC_INT_SCHEME            where product_id  = 8026;
delete from T_INSURED_AMOUNT            where product_id  = 8026;
delete from T_CHARGE_PREM               where product_id  = 8026;
delete from T_BONUS_BASIC_FACTOR        where product_id  = 8026;
delete from T_STDPREM_RATE              where product_id  = 8026;
delete from T_PREMIUM_RATE2             where product_id  = 8026;
delete from T_EXPENSE_RATE              where product_id  = 8026;
delete from T_STAND_PREM_RATE           where product_id  = 8026;
delete from t_fa_def_sub_prem           where main_prd_id = 8026;
delete from t_pul_admin_fee_config      where product_id  = 8026;
delete from t_add_sb_amount_limit       where product_id  = 8026;

-- ============================================================
-- STEP 2: T_PRODUCT_LIFE (master product record)
-- Key LETL002 / SIO settings:
--   INS_TYPE       = '1' (life)
--   SURR_PERMIT    = 'N' (no surrender value)
--   ADD_PERMIT     = 'N' (no FA change for SIO)
--   LOAN_PERMIT    = '' (no policy loan)
--   APL_PERMIT     = 'N' (no APL)
--   RENEW          = 'N' (term product, no auto-renew)
--   MIN_ISSUE_AGE  = 18
--   MAX_ISSUE_AGE  = 74   (SIO: 18-74 ALB)
--   COVER_EXPIRE_AGE = 76 (SIO expiry age)
--   UNDERWRITE_CLASS = '2' (simplified/SIO)
--   UW_ROUTE_TYPE  = '2' (SIO routing)
--   WAITING_PERIOD = 0 (not applicable per spec)
--   MONEY_ID       = VND currency code
--   BUSI_TYPE      = '1' (individual)
--   PRODUCT_TYPE   = '1' (standalone main product)
-- ============================================================
insert into T_PRODUCT_LIFE (
  ORGAN_ID, PRODUCT_ID, PRODUCT_NAME, PRODUCT_ABBR, INTERNAL_ID,
  AREA_LIMIT, AREA_FORBID, HOSPITAL_TYPE,
  UNIT_FLAG, INS_TYPE, ALLY, INDIVIDUAL_GROUP,
  VALUE, EXCEPTION, EXEMPT_TYPE, FIX_INC, DRAW_TYPE,
  START_DATE, END_DATE, PUBLISH,
  AGE_PREM, HAVE_OPTION, MASTER_ID, NEED, RATE,
  OPION_LIMIT, OPTION_MIN_YEAR,
  LIFE_RATE, SUDDEN_RATE, ILL_RATE, EM,
  CHECK_AMOUNT, MAX_AMOUNT, MAX_RELATED,
  MIN_YEAR_PREM, MIN_ONCE_PREM, ONCE_MR,
  RENEW, WOMEN_INSURED, PREGNANT_INSURED, DISABLER_INSURED,
  NOJOB_INSURED, STUDENT_INSURED,
  PAY_EXPIRE_AGE, PAY_EXPIRE_RENEW,
  MAX_ISSUE_AGE, MAX_ISSUE_RENEW,
  MIN_ISSUE_AGE, MAX_RELATED_AGE, MAX_RELATED_RENEW, MIN_RELATED_AGE,
  MIN_RELATED_UNIT, JOB_DIFF, GENDER_DIFF, EXCEPT_DIFF,
  HOUSEKEEPER_DIFF, LEVEL_DIFF, SUB_PRODUCT, SMOKING_DIFF,
  UNDERWRITE_CLASS, ATTACHABLE, INSURE_MONTH,
  COVERAGE_CHARGE, ATTACH_EXEMPT, DUTY, EXEMPT_OBJECT,
  BENEFIT_TYPE, BUSI_TYPE, TARGET_TYPE, PERIOD_TYPE,
  UNDERWRITE_JOB, SURR_PERMIT, ADD_PERMIT, ADD_CALC,
  APL_PERMIT, APL_CALC, LOAN_PERMIT, ACTUARY_RATE,
  BASIC_PAY_PERIOD, BASIC_PAY_ENSURE, BASIC_PAY_TYPE,
  BASIC_INCREASE_YEAR, AMOUNT_DIFF, CATEGORY_DIFF,
  COMM_POL_YEAR, COMM_PREM_YEAR, COMM_PERIOD, COMM_AGE,
  ET_POL_YEAR, ET_GENDER, ET_SMOKING, VALUE_AGE,
  VALUE_GENDER, VALUE_BEN_STATUS, VALUE_POL_YEAR, VALUE_SMOKING,
  EM_GENDER, EM_AGE, EM_SMOKING,
  DRAW_AGE, DRAW_GENDER, DRAW_POL_YEAR, DRAW_SMOKING, DRAW_CHARGE_TYPE,
  PAY_RATE_DIFF, BASIC_PAY_PERIOD_END, RETIRED_DIFF, TABLE_PREM,
  SS_CLAIM_FORMULA, SUR_CHARGE_TYPE, SUR_PAIDUP_STATUS, SUR_PAY_TYPE,
  REDUCE_PAIDUP,
  MIN_INITIAL_PREM, MIN_AMOUNT, MIN_ADD_PREM, MIN_SUR_AMOUNT,
  MIN_SUR_PREM, MIN_ADD_AMOUNT,
  MIN_UNITS, MAX_UNITS, MAX_RELATED_UNITS, MIN_ADD_UNITS,
  MIN_SUR_UNITS, MIN_REMAIN_PREM, MIN_CLAIM_AMOUNT,
  CAPITAL_LAG_DAYS, MORTAGAGE,
  DIVIDEND_AGE, DIVIDEND_HOLDER, DIVIDEND_RELATED,
  DIVIDEND_GENDER, DIVIDEND_BEN_STATUS, DIVIDEND_POL_YEAR, DIVIDEND_SMOKING,
  MIN_COVE_PERIOD, COVER_EXPIRE_AGE, INITIAL_ID, OBJECT_TYPE,
  SECTION_CAL_TYPE, PERIOD_CAL_TYPE, AGE_BASE,
  ISSUE_FEE_BASE, ISSUE_FEE_SOURCE,
  CHARGE_FEE_BASE, CHARGE_FEE_SOURCE,
  MORT_FEE_BASE, MORT_FEE_SOURCE,
  TAX_RATE, BASIC_CHARGE_PERIOD, BASIC_COVERAGE_PERIOD,
  PREMIUM_YEAR_DIFF, PERIOD_DIFF, PAY_PERIOD_DIFF,
  PAY_END_DIFF, PAY_ENSURE_DIFF, PAY_TYPE_DIFF,
  INCREASE_DIFF, AGE_MONTH_DIFF, AGE_MONTH_R_DIFF,
  GENDER_R_DIFF, RETIRED_RATE_DIFF,
  AMOUNT_SECTION, UNITS_SECTION,
  DRAW_PREMIUM_YEAR, DRAW_PERIOD, DRAW_PAY_PERIOD, DRAW_PAY_END,
  DRAW_PAY_ENSURE, DRAW_PAY_TYPE, DRAW_INCREASE, DRAW_PAY_RATE,
  DRAW_EXCEPT, DRAW_HOUSE, DRAW_RETIRED, DRAW_JOB_CATE,
  DRAW_CATEGORY, DRAW_AGE_MONTH, DRAW_AGE_MONTH_R, DRAW_GENDER_R,
  DRAW_LEVEL, DRAW_AMOUNT, DRAW_RETIRED_RATE,
  PREMIUM_SECTION, COMM_ORGAN, COMM_BRANCH_BANK, COMM_DERIVATION, COMM_FEE_TYPE,
  ISSUE_FEE_TIMES, ISSUE_POL_YEAR, CHARGE_PREM_TYPE, CHARGE_POL_YEAR,
  ET_PREMIUM_YEAR, ET_PERIOD, ET_PAY_PERIOD, ET_PAY_END,
  ET_PAY_ENSURE, ET_PAY_TYPE, ET_INCREASE, ET_PAY_RATE,
  ET_EXCEPT, ET_HOUSE, ET_RETIRED, ET_JOB_CATE, ET_CATEGORY,
  ET_AGE, ET_AGE_MONTH, ET_AGE_MONTH_R, ET_GENDER_R, ET_LEVEL,
  MORT_PREMIUM_YEAR, MORT_PERIOD, MORT_JOB_CATE, MORT_GENDER,
  MORT_SMOKING, MORT_AGE, MORT_AGE_MONTH, MORT_LEVEL,
  MORT_POL_YEAR, MORT_PREM_TYPE,
  VALUE_PREMIUM_YEAR, VALUE_PERIOD, VALUE_PAY_PERIOD, VALUE_PAY_END,
  VALUE_PAY_ENSURE, VALUE_PAY_TYPE, VALUE_INCREASE, VALUE_PAY_RATE,
  VALUE_EXCEPT, VALUE_HOUSE, VALUE_RETIRED, VALUE_JOB_CATE,
  VALUE_CATEGORY, VALUE_AGE_MONTH, VALUE_AGE_MONTH_R, VALUE_GENDER_R,
  VALUE_LEVEL,
  EM_PREMIUM_YEAR, EM_PERIOD, EM_POL_YEAR, EM_MIN_EM, EM_MAX_EM,
  EM_UNIT_AMOUNT, EM_PERIOD_CAL_TYPE, EM_AGE_BASE,
  VALUE_UNIT_AMOUNT, VALUE_CAL_TYPE, VALUE_CHARGE_TYPE,
  BONUS_ALLOT, BONUS_CAL_TYPE, PREMIUM_DEFINE,
  MORT_UNIT_AMOUNT, CHARGE_UNIT_AMOUNT,
  CHARGE_PREMIUM_YEAR, CHARGE_PERIOD,
  COMM_TYPE_ID, COMM_CALC_TYPE, MAX_CPF,
  MONEY_ID, PAY_AMOUNT, PAY_COUNT_TYPE,
  LIFE_TABLE_GENDER, LIFE_TABLE_SMOKING, LIFE_TABLE_ANNUITY,
  REGU_TO_SINGLE, SA_FORMULA, SA_ACCUM,
  STAND_CHARGE_TYPE, STAND_PERIOD, STAND_PREMIUM_YEAR, STAND_YEAR, STAND_CALC_TYPE,
  ISSUE_PREM_TYPE, PERMIT_CPF, UNIVERSAL_PREM,
  LIVE_RANGE_DIFF, MOVE_RANGE_DIFF, SUR_BEGIN_PAY, GUARANTEE_RENEW,
  BENEFIT_LEVEL, CLAIM_CNT,
  ONCE_PER_PAY_LIMIT, YEAR_PER_PAY_LIMIT, COVERAGE_PER_PAY_LIMIT,
  LIFE_PAY_LIMIT, DAY_PER_PAY_LIMIT, MONTH_PER_PAY_LIMIT,
  CHECKED, INSERT_PERSON, INSERT_DATE, UPDATER_ID, UPDATE_TIME,
  SYS_LOCK_TIME, SYS_LOCKER_ID, SYS_LOCK_STATUS,
  ONCE_PAY_RATE, COVERAGE_EXCEPT, PSEUDO,
  PERMIT_PRS, PRS_UNIT_AMOUNT, PRS_FORMULA,
  POLICYHOLDER, RI_RISK_TYPE, RES_FACTOR, PREM_TABLE,
  RELATED_TYPE_PREM2, RELATED_PREM2, FEE_YEAR_PREM2, AGE_PREM2, GENDER_PREM2,
  COMM_AMOUNT,
  BONUS_AGE_1, BONUS_GENDER_1, BONUS_AGE_2, BONUS_SMOKING, BONUS_WAIVED,
  BONUS_POLICY_YEAR, BONUS_PREMIUM_YEAR, BONUS_PERIOD,
  BONUS_PAY_PERIOD, BONUS_PAY_TYPE, UW_MANUAL, EXEMPTED_AGE_PREM2,
  PRODUCT_TYPE, INIT_PREM_TIME, NORM_PAY_COUNT_TYPE, NORM_PAY_AMOUNT,
  BASE_UNIT, MAX_ADD_RISK, RISK_RATE_1, BSA_FORMULA,
  DEDUCT_PERIOD_BASE, ISSU_FEE_MODE, CHARGE_FEE_MODE, MORT_FEE_MODE,
  MAX_SUR_TIMES, YEARS_ALLOW_SUR, MIN_SUR_REMAIN_VAL, MAX_SUR_PERCENT,
  FREE_SUR_UNIT, FREE_SUR_PERIOD, SURRENDER_FEE,
  MIN_TOPUP_AMT, MIN_REGULAR_AMT,
  DIAGNOSIS_FEE, GURNT_INT_METH, GURNT_SETTLE_METH,
  SURPLUS_RATE, INSURER_BONUS_RATE, GURNT_RATE_TYPE,
  BONUS_RATE_TYPE, TMA_RATE_TYPE, LOAN_SPECIAL_RATE, SPECIAL_RATE_TYPE,
  CHILD_ACCOUNT_DEF, ISSUE_SA, ISSUE_ACCOUNT_ATT, ISSUE_ISSUE_DATE,
  CHARGE_PREM, CHARGE_ACCUM_PREM, CHARGE_ACCOUNT_ATT,
  PART_SURR_TIMES, PREM_BONUS_YEARS, PREM_BONUS_RATE, PREM_BONUS,
  SIMPLE_COMPOUND, INT_PERIOD_TYPE, PREM_BONUS_CON_YEARS, MAX_LOAN_RATE,
  BONUS_CALC_MOTHOD, BONUS_SETTLE_METHOD, INT_SETTLE_METHOD,
  FREE_PART_SURR, YEARS_PART_SURR, PART_SURR_PERCENT, FREE_PART_SURR_RATE,
  INDIV_PART_SURR, INDIV_ADD, YEARS_ADD, ADD_TIMES,
  DECREASE, DECREASE_TIMES, INDIV_SURR,
  ISSUE_FORMULA, ISSUE_FORMULA_RATE, IS_APPOINT_SA,
  UW_ROUTE_TYPE, IS_POLICY_PRINT,
  MIN_MONTH_PREM, MIN_QUARTER_PREM, MIN_HALF_YEAR_PREM,
  RIDER_CHARGE_PERIOD, RIDER_COVER_PERIOD,
  MIN_DEATH_BENE, SURR_CHARGE_BASE,
  DISTRIBUTION_FLAG, OVERDUE_OPTION,
  SA_FLOORED_RATE, SA_CAPPED_RATE,
  TPD_BENEFIT_FLAG, TPD_RATE, UAB_RATE,
  IS_PA_PRODUCT, DEDUCT_AV_IND,
  WAITING_PERIOD, SURVIVAL_PERIOD,
  PACKAGE, UL_BENEFIT, HSP_RATE,
  CALC_ORDER, MAIN_RELATION, YEARS_LOAN, WAIVER_PREM, IS_SINGLE, AVAIL_TRAINING
)
values (
  '1', 8026, 'Level Term Life - SIO Question', 'LETL002', 'LETL002',
  '0', '', '',
  '2', '1', '0', '1',
  'N', '', 0, '', '',
  to_date('01-07-2026', 'dd-mm-yyyy'), null, 'N',
  '1', 'N', null, 'N', 1.00,
  9999999999, 0,
  1.00, 0.00, 0.00, 9999,
  4000000000, 4000000000, 9999999999,
  0, 0, 'N',
  -- RENEW/insured flags: term product, no renewal automation
  'N', 'Y', 'N', 'N',
  'N', 'N',
  -- PAY_EXPIRE_AGE=76 (SIO expiry), MAX_ISSUE_AGE=74, MIN_ISSUE_AGE=18
  76, 999,
  74, 999,
  18, 999, 999, 0,
  1, '1', 'N', 'N',
  'N', 'N', 'N', 'N',
  -- UNDERWRITE_CLASS='2' (SIO), not attachable
  '2', 'N', 'N',
  'N', 'N', '', '',
  '41', '1', '1', '3', '1',
  -- SURR_PERMIT=N, ADD_PERMIT=N (no FA change for SIO), LOAN_PERMIT=N, APL_PERMIT=N
  '0', 'N', 'N', 'N',
  'N', 'N', 'N', 0.00,
  'N', 'N', '0',
  0, 'N', 'N',
  'Y', 'N', 'N', 'N',
  'N', 'N', 'N', 'N',
  'N', 'N', 'N',
  'N', 'N', 'N', 'N', 'N',
  'N', 'N', 'N',
  -- MIN_AMOUNT (SIO min FA not defined - set to 100,000,000), MAX_AMOUNT = 4,000,000,000
  0, 100000000, 0, 0,
  0, 0,
  0, 9999999999, 9999999999, 0,
  0, 0, 0,
  0, 'N',
  'N', 'N', 'N',
  'N', 'N', 'N', 'N',
  -- MIN_COVE_PERIOD=24months, COVER_EXPIRE_AGE=76 (SIO)
  24, 76, 'LETL002', '1',
  '1', '1', '1',
  '1', '0', '6', '1', '1',
  '2', '6', 0.0000,
  'N', 'N',
  'Y', 'Y', 'N', 'N',
  'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
  'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
  'N', 'N', 'N', 'N', 'N', 'N',
  'N', 'N', 'N', 'N',
  'N', 'N', 'Y', 'N', 'N', 'Y', 'Y',
  'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
  '0', 'N', 'N', 'N', 'N', 'N', 'N',
  'N', 'Y', 'N',
  '0', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
  'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
  'N', 'N', 'N', 'N',
  'Y', 'Y', 1000, '1', '2', 0,
  '0', 'N', '0', '', '1', 1000, 1000,
  'N', 'N', 'N', 'N',
  9999999999, 0, 0, '', 'N', 'N', 'N', 'N',
  -- SA_FORMULA for term life death benefit = 100% FA
  'BASIC_AMOUNT_FORMULA_2', 'Y', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
  'Y', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
  'Y', 0, to_date('01-07-2026', 'dd-mm-yyyy'),
  0, to_date('01-07-2026', 'dd-mm-yyyy'),
  null, 0, '0', 'N', 'N', 'N', 'N',
  0, '', '', '0', '', '1',
  'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
  'Y', 'N',
  -- Policy term 24-120 months, coverage period type '3'=months
  99, 'W', '1', 1000, 0, null, 1.000000,
  'BASIC_AMOUNT_FORMULA_2', '2', '4', '0', '4',
  0, 0, 0, 1.000000, '', null, 0.00, 0.00, 0.00,
  'N', '2', '4', 1.000000, 0.000000,
  '0', '0', '0', 'N', '0',
  'N', 'N', 'N', 'N', 'N', 'N', 'N',
  2, null, null, 'N', '2', '1', null, 0.800,
  '0', '0', '4', null, 2, 0.800000, 0.000000,
  'N', 'N', 2, 1, 'Y', 1,
  'N', '', null, '', '2',
  -- UW_ROUTE_TYPE='2' (SIO), IS_POLICY_PRINT='Y'
  'Y', 0, 0, 0, 1, 1,
  -- LIFE_PAY_LIMIT for term = FA amount
  4000000000.00, 2, 'A', '1', null, null,
  '0', 0.00, 1.00, '0', 'N', null, null,
  '', null, null, 1, null, 2, null, 0, 'Y'
);

-- ============================================================
-- STEP 3: T_LIFE_BASIC (coverage/payment period definitions)
-- LETL002 SIO: Coverage 24-120 months, premium = coverage term
-- PAY_TYPE='4' = monthly/quarterly/half-yearly/yearly (all modes)
-- CHARGE_PERIOD='3' (months), COVERAGE_PERIOD='3' (months)
-- MAX_INSURED_AGE=74 ALB, MIN_INSURED_AGE=18
-- ============================================================
insert into T_LIFE_BASIC (
  PRODUCT_ID, BASIC_ID, PAY_PERIOD, PAY_YEAR, END_PERIOD, END_YEAR,
  PAY_ENSURE, PAY_TYPE, CHARGE_PERIOD, CHARGE_YEAR,
  MAX_INSURED_AGE, MAX_INSURED_RENEW, MIN_INSURED_AGE,
  COVERAGE_PERIOD, COVERAGE_YEAR, INCREASE_YEAR, INCREASE_RATE,
  BASIC_CODE, INCREASE_FREQ, MIN_INSURED_UNIT, SIMPLE_COMPOUND
)
values (8026, 8026001, '3', 0, '3', 0, 0, '4', '3', 76, 74, 999, 18, '3', 120, 0, 0.0000, 'LETL002', '0', '1', '0');

-- ============================================================
-- STEP 4: T_UNIT_AMOUNT (Face Amount boundaries - SIO generic)
-- Min FA = 100,000,000 VND / Max FA = 4,000,000,000 VND
-- Partner-specific overrides (HDB/Vikki) are in partner scripts
-- ============================================================
insert into T_UNIT_AMOUNT (PRODUCT_ID, MIN_AMOUNT, MAX_AMOUNT, UNIT_AMOUNT)
values (8026, 100000000, 4000000000, 1000);

-- ============================================================
-- STEP 5: T_PROD_TARGET (valuation target group)
-- ============================================================
insert into T_PROD_TARGET (TARGET_ID, TARGET_NAME, PRODUCT_ID)
values (8026, 'LETL002', 8026);

-- ============================================================
-- STEP 6: T_PROD_TARGET_CHK (quarterly check-points)
-- ============================================================
insert into T_PROD_TARGET_CHK (CHECK_POINT_ID, START_POLICY_MON, END_POLICY_MON, CHECK_MONTH, CHK_POINT_DIR, CHK_POINT_DAY, TARGET_ID, PRODUCT_ID)
values (80261, 1, 3, 1, 1, 1, 8026, 8026);
insert into T_PROD_TARGET_CHK (CHECK_POINT_ID, START_POLICY_MON, END_POLICY_MON, CHECK_MONTH, CHK_POINT_DIR, CHK_POINT_DAY, TARGET_ID, PRODUCT_ID)
values (80262, 4, 6, 4, 1, 1, 8026, 8026);
insert into T_PROD_TARGET_CHK (CHECK_POINT_ID, START_POLICY_MON, END_POLICY_MON, CHECK_MONTH, CHK_POINT_DIR, CHK_POINT_DAY, TARGET_ID, PRODUCT_ID)
values (80263, 7, 9, 7, 1, 1, 8026, 8026);
insert into T_PROD_TARGET_CHK (CHECK_POINT_ID, START_POLICY_MON, END_POLICY_MON, CHECK_MONTH, CHK_POINT_DIR, CHK_POINT_DAY, TARGET_ID, PRODUCT_ID)
values (80264, 10, 12, 10, 1, 1, 8026, 8026);

-- ============================================================
-- STEP 7: T_PROD_TARGET_PERIOD (annual policy year bands up to 120 months)
-- ============================================================
insert into T_PROD_TARGET_PERIOD (PERIOD_ID, START_POLICY_MON, END_POLICY_MON, TARGET_ID, PRODUCT_ID) values (802601,   1,  12, 8026, 8026);
insert into T_PROD_TARGET_PERIOD (PERIOD_ID, START_POLICY_MON, END_POLICY_MON, TARGET_ID, PRODUCT_ID) values (802602,  13,  24, 8026, 8026);
insert into T_PROD_TARGET_PERIOD (PERIOD_ID, START_POLICY_MON, END_POLICY_MON, TARGET_ID, PRODUCT_ID) values (802603,  25,  36, 8026, 8026);
insert into T_PROD_TARGET_PERIOD (PERIOD_ID, START_POLICY_MON, END_POLICY_MON, TARGET_ID, PRODUCT_ID) values (802604,  37,  48, 8026, 8026);
insert into T_PROD_TARGET_PERIOD (PERIOD_ID, START_POLICY_MON, END_POLICY_MON, TARGET_ID, PRODUCT_ID) values (802605,  49,  60, 8026, 8026);
insert into T_PROD_TARGET_PERIOD (PERIOD_ID, START_POLICY_MON, END_POLICY_MON, TARGET_ID, PRODUCT_ID) values (802606,  61,  72, 8026, 8026);
insert into T_PROD_TARGET_PERIOD (PERIOD_ID, START_POLICY_MON, END_POLICY_MON, TARGET_ID, PRODUCT_ID) values (802607,  73,  84, 8026, 8026);
insert into T_PROD_TARGET_PERIOD (PERIOD_ID, START_POLICY_MON, END_POLICY_MON, TARGET_ID, PRODUCT_ID) values (802608,  85,  96, 8026, 8026);
insert into T_PROD_TARGET_PERIOD (PERIOD_ID, START_POLICY_MON, END_POLICY_MON, TARGET_ID, PRODUCT_ID) values (802609,  97, 108, 8026, 8026);
insert into T_PROD_TARGET_PERIOD (PERIOD_ID, START_POLICY_MON, END_POLICY_MON, TARGET_ID, PRODUCT_ID) values (802610, 109, 120, 8026, 8026);

-- ============================================================
-- STEP 8: T_PROD_ACC_ATT_CFG / T_PROD_ACC_CFG (account config)
-- Term life = no fund account, use default account type 3
-- ============================================================
insert into T_PROD_ACC_ATT_CFG (PRODUCT_ID, ACCOUNT_ATT_TYPE) values (8026, 3);
insert into T_PROD_ACC_CFG (PRODUCT_ID, ACCOUNT_NAME, ACCOUNT_ATT_TYPE) values (8026, 'DEFAULT', 3);

-- ============================================================
-- STEP 9: T_PRODUCT_SURRENDER
-- No surrender value for LETL (pure term)
-- ============================================================
insert into T_PRODUCT_SURRENDER (
  PRODUCT_ID, CHARGE_TYPE, PAIDUP_STATUS, PAY_TYPE,
  FORMULA_NAME, BEGIN_PAY, SA_FORMULA,
  BONUS_FORMULA, MIN_GUARANTEE_FORMULA, PAYUP_FORMULA,
  DIVIDEND_FORMULA, COUPON_FORMULA
)
values (8026, '0', '0', '0', '', 0, '', null, null, null, null, null);

-- ============================================================
-- STEP 10: T_LIABILITY_CONFIG (benefit payable configurations)
-- LIAB 101 = Death benefit (100% FA)
-- LIAB 801 = ADB (Accidental Death Benefit)
-- LIAB 802 = ADD (Accidental Dismemberment & Disability)
-- ============================================================
-- Death benefit
insert into T_LIABILITY_CONFIG (
  PRODUCT_ID, LIAB_ID, PAY_PERIOD, PAY_MONTH,
  PAY_AGE1, PAY_AGE2, PAY_END_PERIOD, PAY_END_YEAR,
  PAY_PAY_ENSURE, PAY_PAY_TYPE, PAY_PREMIUM_YEAR,
  LIAB_PREM_YEAR, LIAB_PERIOD, LIAB_CHARGE_TYPE,
  LIAB_GENDER, LIAB_AGE, LIAB_MONTH, LIAB_LIAB_AGE,
  LIAB_BENE_LEVEL, LIAB_PAY_ENSURE,
  WAIT_DAYS, SURGERY_TYPE, SICKROOM_TYPE, HOSPITAL_SPECI,
  HOSPITAL_TYPE, RELATION_S, CLAIM_CNT,
  ONCE_EXCEPT, ONCE_PAY_RATE, ONCE_PER_PAY_LIMIT,
  YEAR_EXCEPT, YEAR_PER_PAY_LIMIT,
  COVERAGE_EXCEPT, COVERAGE_PER_PAY_LIMIT, LIFE_PAY_LIMIT,
  DAY_PER_PAY_LIMIT, MONTH_PER_PAY_LIMIT,
  PAY_AGE, HOSPITAL_OWNER, HOSPITAL_TIME, PAY_AMOUNT,
  INSERT_TIME, UPDATE_TIME,
  HOSPITAL_NETWORK, HOSPITAL_DAYS_INDI, OUTPATIENT_TIMES_INDI, PRE_ACCUM_RATE
)
values (8026, 101, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
        'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
        0, 'N', 'N', 'N', 'N', 'N', 'N',
        'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
        'N', 'N', 'N', 'N', SYSDATE, SYSDATE, 'N', 'N', 'N', null);

-- ADB (Accidental Death Benefit)
insert into T_LIABILITY_CONFIG (
  PRODUCT_ID, LIAB_ID, PAY_PERIOD, PAY_MONTH,
  PAY_AGE1, PAY_AGE2, PAY_END_PERIOD, PAY_END_YEAR,
  PAY_PAY_ENSURE, PAY_PAY_TYPE, PAY_PREMIUM_YEAR,
  LIAB_PREM_YEAR, LIAB_PERIOD, LIAB_CHARGE_TYPE,
  LIAB_GENDER, LIAB_AGE, LIAB_MONTH, LIAB_LIAB_AGE,
  LIAB_BENE_LEVEL, LIAB_PAY_ENSURE,
  WAIT_DAYS, SURGERY_TYPE, SICKROOM_TYPE, HOSPITAL_SPECI,
  HOSPITAL_TYPE, RELATION_S, CLAIM_CNT,
  ONCE_EXCEPT, ONCE_PAY_RATE, ONCE_PER_PAY_LIMIT,
  YEAR_EXCEPT, YEAR_PER_PAY_LIMIT,
  COVERAGE_EXCEPT, COVERAGE_PER_PAY_LIMIT, LIFE_PAY_LIMIT,
  DAY_PER_PAY_LIMIT, MONTH_PER_PAY_LIMIT,
  PAY_AGE, HOSPITAL_OWNER, HOSPITAL_TIME, PAY_AMOUNT,
  INSERT_TIME, UPDATE_TIME,
  HOSPITAL_NETWORK, HOSPITAL_DAYS_INDI, OUTPATIENT_TIMES_INDI, PRE_ACCUM_RATE
)
values (8026, 801, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
        'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
        0, 'N', 'N', 'N', 'N', 'N', 'N',
        'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
        'N', 'N', 'N', 'N', SYSDATE, SYSDATE, 'N', 'N', 'N', null);

-- ADD (Accidental Dismemberment and Disability)
insert into T_LIABILITY_CONFIG (
  PRODUCT_ID, LIAB_ID, PAY_PERIOD, PAY_MONTH,
  PAY_AGE1, PAY_AGE2, PAY_END_PERIOD, PAY_END_YEAR,
  PAY_PAY_ENSURE, PAY_PAY_TYPE, PAY_PREMIUM_YEAR,
  LIAB_PREM_YEAR, LIAB_PERIOD, LIAB_CHARGE_TYPE,
  LIAB_GENDER, LIAB_AGE, LIAB_MONTH, LIAB_LIAB_AGE,
  LIAB_BENE_LEVEL, LIAB_PAY_ENSURE,
  WAIT_DAYS, SURGERY_TYPE, SICKROOM_TYPE, HOSPITAL_SPECI,
  HOSPITAL_TYPE, RELATION_S, CLAIM_CNT,
  ONCE_EXCEPT, ONCE_PAY_RATE, ONCE_PER_PAY_LIMIT,
  YEAR_EXCEPT, YEAR_PER_PAY_LIMIT,
  COVERAGE_EXCEPT, COVERAGE_PER_PAY_LIMIT, LIFE_PAY_LIMIT,
  DAY_PER_PAY_LIMIT, MONTH_PER_PAY_LIMIT,
  PAY_AGE, HOSPITAL_OWNER, HOSPITAL_TIME, PAY_AMOUNT,
  INSERT_TIME, UPDATE_TIME,
  HOSPITAL_NETWORK, HOSPITAL_DAYS_INDI, OUTPATIENT_TIMES_INDI, PRE_ACCUM_RATE
)
values (8026, 802, 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
        'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
        0, 'N', 'N', 'N', 'N', 'N', 'N',
        'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N', 'N',
        'N', 'N', 'N', 'N', SYSDATE, SYSDATE, 'N', 'N', 'N', null);

-- ============================================================
-- STEP 11: T_LIAB_PAY_PARAM / T_LIAB_PAY_RELATIVE (claim calc functions)
-- 101 = Death: 100% FA -> P_CLM_CALC_G25
-- 801 = ADB:   multiplier (100/200/300%) -> P_CLM_CALC_G4
-- 802 = ADD:   schedule % of FA -> P_CLM_CALC_G4
-- ============================================================
insert into T_LIAB_PAY_PARAM (PRODUCT_ID, LIAB_ID, RELV1_VALUE, RELV2_VALUE, RELV3_VALUE, RELV4_VALUE, RELV5_VALUE, RELV6_VALUE, PARAM_1, PARAM_2, SVC_CNT_FUNC, BSC_PAY_FUNC, INSERT_TIME, UPDATE_TIME, COVERAGE, RECORDER_ID, UPDATER_ID, LIST_ID)
values (8026, 101, '', '', '', '', '', '', 1.00, null, '', 'P_CLM_CALC_G25', SYSDATE, SYSDATE, null, 0, 0, 802601);

insert into T_LIAB_PAY_PARAM (PRODUCT_ID, LIAB_ID, RELV1_VALUE, RELV2_VALUE, RELV3_VALUE, RELV4_VALUE, RELV5_VALUE, RELV6_VALUE, PARAM_1, PARAM_2, SVC_CNT_FUNC, BSC_PAY_FUNC, INSERT_TIME, UPDATE_TIME, COVERAGE, RECORDER_ID, UPDATER_ID, LIST_ID)
values (8026, 801, null, null, null, null, null, null, 1, null, null, 'P_CLM_CALC_G4', SYSDATE, SYSDATE, null, 0, 0, 802602);

insert into T_LIAB_PAY_PARAM (PRODUCT_ID, LIAB_ID, RELV1_VALUE, RELV2_VALUE, RELV3_VALUE, RELV4_VALUE, RELV5_VALUE, RELV6_VALUE, PARAM_1, PARAM_2, SVC_CNT_FUNC, BSC_PAY_FUNC, INSERT_TIME, UPDATE_TIME, COVERAGE, RECORDER_ID, UPDATER_ID, LIST_ID)
values (8026, 802, null, null, null, null, null, null, 1, null, null, 'P_CLM_CALC_G4', SYSDATE, SYSDATE, null, 0, 0, 802603);

insert into T_LIAB_PAY_RELATIVE (PRODUCT_ID, LIAB_ID, RELATIVITY1, RELATIVITY2, RELATIVITY3, RELATIVITY4, RELATIVITY5, RELATIVITY6, INSERT_TIME, UPDATE_TIME, LIST_ID, RECORDER_ID, UPDATER_ID, IS_AUTO_CLAIM_APPLY)
values (8026, 101, null, null, null, null, null, null, SYSDATE, SYSDATE, 3001, 0, 0, 'N');
insert into T_LIAB_PAY_RELATIVE (PRODUCT_ID, LIAB_ID, RELATIVITY1, RELATIVITY2, RELATIVITY3, RELATIVITY4, RELATIVITY5, RELATIVITY6, INSERT_TIME, UPDATE_TIME, LIST_ID, RECORDER_ID, UPDATER_ID, IS_AUTO_CLAIM_APPLY)
values (8026, 801, null, null, null, null, null, null, SYSDATE, SYSDATE, 3002, 0, 0, 'N');
insert into T_LIAB_PAY_RELATIVE (PRODUCT_ID, LIAB_ID, RELATIVITY1, RELATIVITY2, RELATIVITY3, RELATIVITY4, RELATIVITY5, RELATIVITY6, INSERT_TIME, UPDATE_TIME, LIST_ID, RECORDER_ID, UPDATER_ID, IS_AUTO_CLAIM_APPLY)
values (8026, 802, null, null, null, null, null, null, SYSDATE, SYSDATE, 3003, 0, 0, 'N');

-- ============================================================
-- STEP 12: T_PAY_LIABILITY (payout rules per benefit)
-- Death: 100% of FA at any time during coverage
-- ADB: formula-driven multiplier (100/200/300%)
-- ADD: schedule % defined in separate ADD table
-- ============================================================
insert into T_PAY_LIABILITY (PRODUCT_ID, LIAB_ID, PERIOD, MONTH, AGE1, AGE2, END_PERIOD, END_YEAR, PAY_ENSURE, PAY_TYPE, PAY_AMOUNT, PREMIUM_YEAR, PAY_FORMULA)
values (8026, 101, 0, 9999, 999, 999, '0', 0, 0, '0', 1.000000, 0, 'DEATH_BENEFIT_FULL_FA');
insert into T_PAY_LIABILITY (PRODUCT_ID, LIAB_ID, PERIOD, MONTH, AGE1, AGE2, END_PERIOD, END_YEAR, PAY_ENSURE, PAY_TYPE, PAY_AMOUNT, PREMIUM_YEAR, PAY_FORMULA)
values (8026, 801, 0, 9999, 999, 999, '0', 0, 0, '0', 1.000000, 0, 'ADB_MULTIPLIER_FORMULA');
insert into T_PAY_LIABILITY (PRODUCT_ID, LIAB_ID, PERIOD, MONTH, AGE1, AGE2, END_PERIOD, END_YEAR, PAY_ENSURE, PAY_TYPE, PAY_AMOUNT, PREMIUM_YEAR, PAY_FORMULA)
values (8026, 802, 0, 9999, 999, 999, '0', 0, 0, '0', 1.000000, 0, 'ADD_SCHEDULE_FORMULA');

-- ============================================================
-- STEP 13: T_PRODUCT_CHARGE (modal premium factors)
-- From spec: Monthly=0.0975, Quarterly=0.28, Half-Yearly=0.53, Yearly=1.00
-- CHARGE_TYPE: 1=Annual, 2=Half-Yearly, 3=Quarterly, 4=Monthly
-- MODEL_TYPE 1=standard
-- ============================================================
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '1', 1.000000,  '1'); -- Annual
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '2', 0.530000,  '1'); -- Half-Yearly
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '3', 0.280000,  '1'); -- Quarterly
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '4', 0.097500,  '1'); -- Monthly
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '5', 0.000000,  '1');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '7', 0.000000,  '1');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '1', 0.000000,  '2');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '2', 0.000000,  '2');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '3', 0.000000,  '2');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '4', 1.000000,  '2');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '5', 0.000000,  '2');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '7', 0.000000,  '2');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '1', 0.000000,  '3');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '2', 0.000000,  '3');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '3', 0.000000,  '3');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '4', 1.000000,  '3');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '5', 0.000000,  '3');
insert into T_PRODUCT_CHARGE (PRODUCT_ID, CHARGE_TYPE, CHARGE_RATE, MODEL_TYPE) values (8026, '7', 0.000000,  '3');

-- ============================================================
-- STEP 14: T_COMMISION (HDB commission schedule per spec)
-- Year 1: 40%, Year 2: 20%, Years 3-5: 15%, Year 6+: 0%
-- FEE_TYPE 1 = new business commission, 2 = renewal
-- All policy years 1-99 defined as per reference product pattern
-- ============================================================
-- Year 1
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 1, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.400000, '1', '0', '0', 1, '0', 1, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 1, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.400000, '1', '0', '0', 1, '0', 2, '1', 0.00, 0, 99);
-- Year 2
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 2, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.200000, '1', '0', '0', 1, '0', 1, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 2, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.200000, '1', '0', '0', 1, '0', 2, '1', 0.00, 0, 99);
-- Year 3
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 3, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.150000, '1', '0', '0', 1, '0', 1, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 3, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.150000, '1', '0', '0', 1, '0', 2, '1', 0.00, 0, 99);
-- Year 4
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 4, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.150000, '1', '0', '0', 1, '0', 1, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 4, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.150000, '1', '0', '0', 1, '0', 2, '1', 0.00, 0, 99);
-- Year 5
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 5, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.150000, '1', '0', '0', 1, '0', 1, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 5, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.150000, '1', '0', '0', 1, '0', 2, '1', 0.00, 0, 99);
-- Year 6+ (0% commission) - years 6 through 10
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 6, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.000000, '1', '0', '0', 1, '0', 1, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 6, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.000000, '1', '0', '0', 1, '0', 2, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 7, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.000000, '1', '0', '0', 1, '0', 1, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 7, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.000000, '1', '0', '0', 1, '0', 2, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 8, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.000000, '1', '0', '0', 1, '0', 1, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 8, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.000000, '1', '0', '0', 1, '0', 2, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 9, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.000000, '1', '0', '0', 1, '0', 1, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 9, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.000000, '1', '0', '0', 1, '0', 2, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 10, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.000000, '1', '0', '0', 1, '0', 1, '1', 0.00, 0, 99);
insert into T_COMMISION (PRODUCT_ID, PREMIUM_YEAR, PERIOD, AGE, YEAR, START_DATE, END_DATE, COMMISION_RATE, AGENT_CATE, ORGAN_ID, BRANCH_BANK, COMMISION_TYPE_ID, DERIVATION, FEE_TYPE, CALC_TYPE, COMMISION_MONTHS, LOW_AGE, HIGH_AGE)
values (8026, 0, 0, 999, 10, to_date('01-07-2026','dd-mm-yyyy'), to_date('09-09-9999','dd-mm-yyyy'), 0.000000, '1', '0', '0', 1, '0', 2, '1', 0.00, 0, 99);

-- ============================================================
-- STEP 15: T_DISTRIBUTION_TYPE (distribution channels)
-- 1=Digital/Consumer Partnership, 2=Banca, 3=Agency
-- ============================================================
insert into t_product_distri_type (PRODUCT_ID, DISTRI_TYPE) values (8026, '1'); -- Digital / consumer partnership
insert into t_product_distri_type (PRODUCT_ID, DISTRI_TYPE) values (8026, '2'); -- Bancassurance
insert into t_product_distri_type (PRODUCT_ID, DISTRI_TYPE) values (8026, '3'); -- Agency

-- ============================================================
-- STEP 16: T_PROPOSAL_AMOUNT_LIMIT (SIO FA limits generic)
-- Partner-specific limits (HDB/Vikki) in partner patch script
-- ============================================================
insert into t_proposal_amount_limit (PRODUCT_ID, AGE_FROM, AGE_TO, MIN_AMOUNT, MAX_AMOUNT)
values (8026, 18, 74, 100000000, 4000000000);

COMMIT;
