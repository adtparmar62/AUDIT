-- ============================================================
-- LETL002 (SIO) - MAIN PRODUCT REGISTRATION
-- product_id = 8026
-- Note: Pure term life - no riders attached at Phase 1
--       Riders/Options listed as TBU in product spec
-- ============================================================
delete from t_prt_main_product where product_id = '8026';
delete from t_main_rider where MAIN_ID = '8026';
delete from t_prt_main_rider where MAINPRODUCT_ID = '8026';

insert into t_prt_main_product (MAIN_PRODUCT_ID, BANK_INDICATOR)
values (8026, 'N');

-- Riders TBU per spec Section 3.10 - insert when confirmed
-- insert into t_main_rider (MAIN_ID, RIDER_ID, RIDER_ORDER) values (8026, <RIDER_ID>, 1);
-- insert into t_prt_main_rider (MAINPRODUCT_ID, RIDERPRODUCT_ID) values (8026, <RIDER_ID>);
