-- ============================================================
-- LETL001 (Full UW) - MAIN PRODUCT REGISTRATION
-- product_id = 8027
-- Note: Pure term life - no riders at Phase 2 launch
--       Riders/Options listed as TBU in product spec
-- ============================================================
delete from t_prt_main_product where product_id = '8027';
delete from t_main_rider where MAIN_ID = '8027';
delete from t_prt_main_rider where MAINPRODUCT_ID = '8027';

insert into t_prt_main_product (MAIN_PRODUCT_ID, BANK_INDICATOR)
values (8027, 'N');

-- Riders TBU per spec Section 3.10 - insert when confirmed
-- insert into t_main_rider (MAIN_ID, RIDER_ID, RIDER_ORDER) values (8027, <RIDER_ID>, 1);
-- insert into t_prt_main_rider (MAINPRODUCT_ID, RIDERPRODUCT_ID) values (8027, <RIDER_ID>);
