-- ============================================================
-- LETL PRODUCT DEPLOYMENT - RUN ORDER SCRIPT
-- Generated: 2026-06-03
-- Product:   Level Term Life (LETL) - Chubb Life Vietnam
-- ============================================================
-- PHASE 1 (SIO, required for HDB/Vikki go-live, Jul 2026)
-- ============================================================

-- Step 1: Deploy LETL002 SIO (product_id=8026)
--   @SIO/8026_dml.sql

-- Step 2: Apply HDB partner overrides
--   @SIO/8026_hdb_patch.sql

-- ============================================================
-- PHASE 2 (Full UW, after MOF approval)
-- ============================================================

-- Step 3: Deploy LETL001 Full Underwriting (product_id=8027)
--   @FullUW/8027_dml.sql

-- ============================================================
-- PENDING - TO BE LOADED WHEN ACTUARIAL DATA IS CONFIRMED
-- ============================================================
-- T_PREMIUM_RATE       : Standard premium table (Appendix 8.2 - TBU)
-- T_STDPREM_RATE       : Sub-standard EM/PM rates (Appendix 8.3 - TBU)
-- SIO UW questions     : T_UW_QUESTION insert (Appendix 8.1 - TBU)
-- Vikki commission     : T_COMMISION update for Vikki partner (TBU)
-- Agency/IC bonus      : T_COMMISION bonus rows (TBU)
-- ============================================================

-- PRODUCT CODE REFERENCE
-- LETL001 (Full UW)  = product_id 8027
-- LETL002 (SIO)      = product_id 8026
-- Base product_id    = 8026 (as instructed)
